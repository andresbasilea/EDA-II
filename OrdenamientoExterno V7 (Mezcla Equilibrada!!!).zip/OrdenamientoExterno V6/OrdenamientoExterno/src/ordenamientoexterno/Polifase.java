/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamientoexterno;
import java.util.*;
import java.io.*;
/**
 *
 * @author AndresBasile
 */
public class Polifase {
    /*
        1) crear dos archivos adicionales
        2) atributo final de n claves...
        2.1) pasar elementos a double
        3) leer el original y pasarlo a un array list (ordenarlo con BUBBLE SORT (PRACTICA 7)).
        4) Ciclo while con variable contadora que va a empezar en 0 y verifica que sea menor a "n" (variable final) y que el arraylist sea != empty.
            Dentro del ciclo while convertir cada elemento del arraylist a String y enviarlo a un archivo... (tendria que haber dos ciclos while adentro para mandar a los archivos (1 y 2) y un while afuera
            para verificar que este ordenado 
            Tienes el archivo original arraylist, envias bloques al archivo 1 y 2 y verificas en todo momento que el arraylist tenga elementos (3 ciclos while, dos dentro de uno) el de fuera verifica que el
            arraylist no este vacio. El primer while verifica que no este vacio y una variable contadora que va de 0 a n y cuenta los elementos que se estan enviando, cuando la variable contadora sea igual a n 
            va a pasar al siguiente while. 
            
            OBSERVACION -> CADA QUE SE TERMINA UNO DE LOS CICLOS WHILE DE ADENTRO SE DEBE ESCRIBIR UN MARCADOR EN EL ARCHIVO PARA SEPARAR LOS BLOQUES ENVIADOS.
            
        5) Crear cuatro variables contadoras para los bloques,una para cada archivo (2) que evalue el bloque que nos encontramos leyendo y otra para cada archivo (2) que evalue el numero total de bloques dentro de este archivo.
    
    
    */
    
    String nombre;
    int particiones;
    int tipoOrdenamiento;
    String numeros[];
    double[] numerosDouble = new double[1000];
    double [] L = new double[250];
    double [] R = new double[250];
    String numeros2[];
    String numeros3[];
    
    Polifase(String nombre, int tipoOrdenamiento){
        this.tipoOrdenamiento = tipoOrdenamiento;
        this.nombre = nombre;
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble[i] = Double.parseDouble(numeros[i]);
                }
                if(numeros.length >0 && numeros.length <= 250)
                    particiones = 1;
                if(numeros.length > 250 && numeros.length <= 500)
                    particiones = 2;
                if(numeros.length > 500 && numeros.length <= 750)
                    particiones = 3;
                if(numeros.length > 750 && numeros.length <= 1000)
                    particiones = 4;       
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    void ordenar(){
        try{
            
            
           if(particiones == 1 && tipoOrdenamiento == 1){
                int contador = 0;
                FileWriter f1 = new FileWriter(nombre,false);
                Quicksort qs = new Quicksort();
                qs.sortAscendente(numerosDouble,0,249);
                while(contador<250){
                    f1.write(Double.toString(numerosDouble[contador]));
                    f1.write(",");
                    contador++;
                }
                f1.flush();
                f1.close();
                System.out.println("ARCHIVO ORDENADO CORRECTAMENTE. NOMBRE ARCHIVO FINAL: " + nombre );
           }
           
           
           if(particiones == 1 && tipoOrdenamiento == 2){
                int contador = 249;
                FileWriter f1 = new FileWriter(nombre,false);
                Quicksort qs = new Quicksort();
                qs.sortAscendente(numerosDouble,0,249);
                while(contador>=0){
                    f1.write(Double.toString(numerosDouble[contador]));
                    f1.write(",");
                    contador--;
                }
                f1.flush();
                f1.close();
                System.out.println("ARCHIVO ORDENADO CORRECTAMENTE. NOMBRE ARCHIVO FINAL: " + nombre);
           }
           
           
           if(particiones == 2 && tipoOrdenamiento == 1){
               int contador = 0;
               FileWriter f1 = new FileWriter("f1.txt");
               FileWriter f2 = new FileWriter("f2.txt");
               Quicksort qs = new Quicksort();
               qs.sortAscendente(numerosDouble,0,249);
               while(contador<250){
                   f1.write(Double.toString(numerosDouble[contador]));
                   f1.write(",");
                   contador++;
               }
               f1.flush();
               f1.close();
               qs.sortAscendente(numerosDouble,250,499);
               while(contador<500){
                   f2.write(Double.toString(numerosDouble[contador]));
                   f2.write(",");
                   contador++;
               }
               f2.flush();
               f2.close();
               FileReader lf1 = new FileReader("f1.txt");
               FileReader lf2 = new FileReader("f2.txt");
               BufferedReader lbf1 = new BufferedReader(lf1);
               BufferedReader lbf2 = new BufferedReader(lf2);
               while(true){
                    String valor = lbf1.readLine();
                    if(valor == null)
                        break;
                    numeros2 = valor.split(",");
                    for(int i = 0;i<numeros2.length;i++){
                        if(numeros2[i]!=null)
                            numerosDouble[i] = Double.parseDouble(numeros2[i]);
                    }
                }
                while(true){
                    String valor = lbf2.readLine();
                    if(valor == null)
                        break;
                    numeros3 = valor.split(",");
                    for(int i =0;i<numeros3.length;i++){
                        if(numeros3[i]!=null)
                            numerosDouble[i] = Double.parseDouble(numeros3[i]);
                    }
                }
                lf1.close();
                lf2.close();
                FileWriter f3 = new FileWriter(nombre,false);
                numerosDouble = unirArchivos(numerosDouble,0,249,499);
                contador = 0;
                while(contador<500){
                    f3.write(Double.toString(numerosDouble[contador]));
                    f3.write(",");
                    contador++;
                }
                f3.flush();
                f3.close();                
            }
           
           
           if(particiones == 2 && tipoOrdenamiento == 2){
               int contador = 0;
               FileWriter f1 = new FileWriter("f1.txt");
               FileWriter f2 = new FileWriter("f2.txt");
               Quicksort qs = new Quicksort();
               qs.sortAscendente(numerosDouble,0,249);
               while(contador<250){
                   f1.write(Double.toString(numerosDouble[contador]));
                   f1.write(",");
                   contador++;
               }
               f1.flush();
               f1.close();
               qs.sortAscendente(numerosDouble,250,499);
               while(contador<500){
                   f2.write(Double.toString(numerosDouble[contador]));
                   f2.write(",");
                   contador++;
               }
               f2.flush();
               f2.close();
               FileReader lf1 = new FileReader("f1.txt");
               FileReader lf2 = new FileReader("f2.txt");
               BufferedReader lbf1 = new BufferedReader(lf1);
               BufferedReader lbf2 = new BufferedReader(lf2);
               while(true){
                    String valor = lbf1.readLine();
                    if(valor == null)
                        break;
                    numeros2 = valor.split(",");
                    for(int i = 0;i<numeros2.length;i++){
                        if(numeros2[i]!=null)
                            numerosDouble[i] = Double.parseDouble(numeros2[i]);
                    }
                }
                while(true){
                    String valor = lbf2.readLine();
                    if(valor == null)
                        break;
                    numeros3 = valor.split(",");
                    for(int i =0;i<numeros3.length;i++){
                        if(numeros3[i]!=null)
                            numerosDouble[i] = Double.parseDouble(numeros3[i]);
                    }
                }
                lf1.close();
                lf2.close();
                FileWriter f3 = new FileWriter(nombre,false);
                numerosDouble = unirArchivos(numerosDouble,0,249,499);
                contador = 500;
                while(contador >=0){
                   f3.write(Double.toString(numerosDouble[contador]));
                   f3.write(",");
                   contador--;
                }
                f3.flush();
                f3.close();
            }
           
            if(particiones == 3 && tipoOrdenamiento == 1){
                
            }
            
            if(particiones == 3 && tipoOrdenamiento == 2){
                
            }
            
            if(particiones == 4 && tipoOrdenamiento == 1){
                
            }
            
            if(particiones == 4 && tipoOrdenamiento == 2){
                
            }
            
            
               
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }   
    }
    
    double[] unirArchivos(double arr[], int l, int m, int r){
        int n1 = m - l + 1; 
        int n2 = r - m; 
        
        for (int i=0; i<n1; ++i) 
            L[i] = arr[l + i]; 
        for (int j=0; j<n2; ++j) 
            R[j] = arr[m + 1+ j]; 
       
        int i = 0, j = 0; 
        int k = l; 
        
        while (i < n1 && j < n2) 
        { 
            if (L[i] <= R[j]) 
            { 
                arr[k] = L[i]; 
                i++; 
            } 
            else
            { 
                arr[k] = R[j]; 
                j++; 
            } 
            k++; 
        } 
  
        while (i < n1) { 
            arr[k] = L[i]; 
            i++; 
            k++; 
        } 
  
        while (j < n2) { 
            arr[k] = R[j]; 
            j++; 
            k++; 
        } 
        
        return arr;
    }
    
}
