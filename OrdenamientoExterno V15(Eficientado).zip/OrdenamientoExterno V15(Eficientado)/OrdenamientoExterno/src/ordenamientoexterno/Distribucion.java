package ordenamientoexterno;
import java.util.*;
import java.io.*;
import java.text.*;

public class Distribucion {
    NumberFormat formatoDosDecimales = new DecimalFormat("#0.00");
    public String nombreArchivoOriginal;
    public int tipoOrdenamiento;
    public boolean verificaOrdenamiento;
    static int valorRecursivoMaximo=0;
    String numeros[];
    String bloque[];
    String bloqueAux[];
    
    ArrayList<Double> numerosDouble = new ArrayList<>();
    public LinkedList<String> numerosArchivoOriginalString = new LinkedList<>();
    public ArrayList<ArrayList<Double>> numerosArchivoOriginalArregloDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    
    static String Q0 = "Q0.txt";
    static String Q1 = "Q1.txt";
    static String Q2 = "Q2.txt";
    static String Q3 = "Q3.txt";
    static String Q4 = "Q4.txt";
    static String Q5 = "Q5.txt";
    static String Q6 = "Q6.txt";
    static String Q7 = "Q7.txt";
    static String Q8 = "Q8.txt";
    static String Q9 = "Q9.txt";
    
    ArrayList<String> bloqueArchivoString = new ArrayList<>();
    
    Distribucion(String nombre, int tipoOrdenamiento){
        this.tipoOrdenamiento = tipoOrdenamiento;
        this.nombreArchivoOriginal = nombre;
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }
            }
            for(int i=0; i<numerosDouble.size(); i++){
                numerosArchivoOriginalString.add(formatoDosDecimales.format(numerosDouble.get(i)));
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    public void ValorRecursivoMaximo(){
        for(int t=0; t<numerosArchivoOriginalString.size(); t++){
            for(int q=0; q<numerosArchivoOriginalString.get(t).length(); q++){
                if(valorRecursivoMaximo<numerosArchivoOriginalString.get(t).length()){
                valorRecursivoMaximo = numerosArchivoOriginalString.get(t).length();
                }
            }
        }
    }
    
    public void ArregloDeArreglos(){
        String temporal;
        String temporalDeTemporada;
        for(int t=0; t<numerosArchivoOriginalString.size(); t++){
            numerosArchivoOriginalArregloDouble.add(new ArrayList<>());
            temporal = numerosArchivoOriginalString.get(t);
            //System.out.println("Temporal " + temporal);
            numerosArchivoOriginalArregloDouble.get(t).add(Double.parseDouble(formatoDosDecimales.format(Double.parseDouble(temporal))));
            System.out.println("numArchOriStr " +numerosArchivoOriginalString.get(t));
            temporal = numerosArchivoOriginalArregloDouble.get(t).toString();
            for(int k=1; k<temporal.length()-1;k++){
                numerosArchivoOriginalArregloDouble.get(t).add(new Double(0));
                System.out.println("Arreglo Enteros "+numerosArchivoOriginalArregloDouble.get(t));
                //System.out.println("Temporal " + temporal);
                if(temporal.charAt(k) != 46){
                    temporalDeTemporada = String.valueOf(temporal.charAt(k));
                    numerosArchivoOriginalArregloDouble.get(t).set(k,Double.parseDouble(temporalDeTemporada));
                    //System.out.println("TemporalDeTemporada "+temporalDeTemporada);
                }
            }
            while(numerosArchivoOriginalArregloDouble.get(t).size()<valorRecursivoMaximo){
                numerosArchivoOriginalArregloDouble.get(t).add(1,0.0);
                System.out.println("Arreglo Enteros Arreglado"+numerosArchivoOriginalArregloDouble.get(t));
            }
        }
    }
    
    public void ImprimeArregloDouble(){
        for(int j=0;j<numerosArchivoOriginalArregloDouble.size();j++){
            System.out.println(numerosArchivoOriginalString.get(j));
            for(int k=0; k<numerosArchivoOriginalArregloDouble.get(j).size();k++){
                System.out.println(numerosArchivoOriginalArregloDouble.get(j).get(k));         
            }
        }
    }
    
    public ArrayList<String> lecturaArchivo(String archivo, String nombreArchivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split("/");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueAux = bloque[i].split(",");
                        for(int j=0; j<bloqueAux.length;j++){
                            bloqueArchivoString.add((bloqueAux[j]));
                        }
                        bloqueArchivoString.add("/");
                    }
                }  
                System.out.println("Bloque " + nombreArchivo);
                for(String d : bloqueArchivoString){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
        
    public void radixSort(int posicionVerificando){
        double valor;
        try{
            
            FileReader lf0 = new FileReader(Q0);
            FileReader lf1 = new FileReader(Q1);
            FileReader lf2 = new FileReader(Q2);
            FileReader lf3 = new FileReader(Q3);
            FileReader lf4 = new FileReader(Q4);
            FileReader lf5 = new FileReader(Q5);
            FileReader lf6 = new FileReader(Q6);
            FileReader lf7 = new FileReader(Q7);
            FileReader lf8 = new FileReader(Q8);
            FileReader lf9 = new FileReader(Q9);
            
            BufferedReader blf0 = new BufferedReader(lf0);
            BufferedReader blf1 = new BufferedReader(lf1);
            BufferedReader blf2 = new BufferedReader(lf2);
            BufferedReader blf3 = new BufferedReader(lf3);
            BufferedReader blf4 = new BufferedReader(lf4);
            BufferedReader blf5 = new BufferedReader(lf5);
            BufferedReader blf6 = new BufferedReader(lf6);
            BufferedReader blf7 = new BufferedReader(lf7);
            BufferedReader blf8 = new BufferedReader(lf8);
            BufferedReader bf9 = new  BufferedReader(lf9);
            
            FileWriter f0 = new FileWriter(Q0);
            FileWriter f1 = new FileWriter(Q1);
            FileWriter f2 = new FileWriter(Q2);
            FileWriter f3 = new FileWriter(Q3);
            FileWriter f4 = new FileWriter(Q4);
            FileWriter f5 = new FileWriter(Q5);
            FileWriter f6 = new FileWriter(Q6);
            FileWriter f7 = new FileWriter(Q7);
            FileWriter f8 = new FileWriter(Q8);
            FileWriter f9 = new FileWriter(Q9);
            
            //Escribir los valores de los números en su respectivo archivo de acuerdo a la posición trabajada.
            for(int i=0; i<numerosArchivoOriginalArregloDouble.size(); i++){
                System.out.println("Valor verificando " + numerosArchivoOriginalArregloDouble.get(i).get(0).toString());
                System.out.println("Posicion Ver " + posicionVerificando);
                if(numerosArchivoOriginalArregloDouble.get(i).get(0).toString().length() < posicionVerificando){ //En caso de que el número que se encuentre trabajando sea muy corto.
                    f0.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                    f0.write(",");
                }
                else{
                    valor = numerosArchivoOriginalArregloDouble.get(i).get(posicionVerificando);
                    switch((int)valor){
                            case 0:
                                f0.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f0.write(",");
                                break;
                            case 1:
                                f1.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f1.write(",");
                                break;
                            case 2:
                                f2.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f2.write(",");
                                break;
                            case 3:
                                f3.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f3.write(",");
                                break;
                            case 4:
                                f4.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f4.write(",");
                                break;
                            case 5:
                                f5.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f5.write(",");
                                break;
                            case 6:
                                f6.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f6.write(",");
                                break;
                            case 7:
                                f7.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f7.write(",");
                                break;
                            case 8:
                                f8.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f8.write(",");
                                break;
                            case 9:
                                f9.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(0)));
                                f9.write(",");
                                break;     
                    }
                }
            }

            f0.close();
            f1.close();
            f2.close();
            f3.close();
            f4.close();
            f5.close();
            f6.close();
            f7.close();
            f8.close();
            f9.close();
        }catch(IOException e){
            System.out.println("ERROR DE ARCHIVO");
        }
    }
    
    public void ordenamiento(){
        crearArchivo(Q0, 0);
        crearArchivo(Q1, 1);
        crearArchivo(Q2, 2);
        crearArchivo(Q3, 3);
        crearArchivo(Q4, 4);
        crearArchivo(Q5, 5);
        crearArchivo(Q6, 6);
        crearArchivo(Q7, 7);
        crearArchivo(Q8, 8);
        crearArchivo(Q9, 9);
        ValorRecursivoMaximo();
        ArregloDeArreglos();
        for(int basileKellerMartinez=valorRecursivoMaximo; basileKellerMartinez>1;basileKellerMartinez--){
            radixSort(basileKellerMartinez);
        }
        bloqueArchivoOriginalString = lecturaArchivo(nombreArchivoOriginal, "Original");
    }
    
    public void crearArchivo(String nombre, int cola){
        try {
            File file = new File(nombre);
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("ERROR AL CREAR EL ARCHIVO");
        }

    }
        
}