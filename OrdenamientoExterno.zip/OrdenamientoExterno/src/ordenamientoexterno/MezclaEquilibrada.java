/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamientoexterno;

/**
 *
 * @author AndresBasile
 */
public class MezclaEquilibrada {
    /* 
    1) Leer todo el archivo y guardar sus elementos en un arreglo, tomando en consideracion las comas.
    2) Crear dos nuevos Archivo.
    3) Primer ciclo for recorrer arreglo de numeros original, verificar tamano del arreglo.
    4) Dentro del ciclo for, ciclo while donde verifique que arr[j+1] sea mayor que arr[j], anadiendo los numeros al archivo 1, cuando no se cumple sale y avisa la posicion j+1. Anadir marcador de que acabo bloque.
    5) Otro ciclo while donde verifique que arr[j+1] sea mayor que arr[j], empezando en j+1 anadiendo los numeros al archivo 2, cuando no se cumple sale y avisa la posicion j+1, para la siguiente iteracion del ciclo for del archivo 1. Anadir marcador de que acabo bloque.
    6) Leer de ambos archivos hasta los marcadores y guardar cada bloque en un arreglo para archivo 1 y archivo 2, realizar merge de ambos bloques y almacenarlo en el archivo original, donde se debio borrar todo previamente.
    7) Avanzar al siguiente bloque de los dos archivos
    8) Funcion recursiva de mezcla equilibrada para ordenar, verificando que el arreglo del archivo original este ordenado. Sobre el archivo original no se marcadores.
    */
    
    MezclaEquilibrada(String archivo, int tipoOrdenamiento){
        
    }
    
    
    
    
    
    
    
    
}
