package ordenamientoexterno;
import java.util.*;
import java.io.*;

/**
*
* Implementa el método de ordenamiento externo por <b>distribución</b>. El método de ordenamiento
* por distribución permite ordenar números a partir del uso de 10 archivos auxiliares, en los cuales
* por medio del procesamiento de dígitos de forma individual, se va realizando el ordenamiento trabajando
* primero con los valores <b>menos significativos</b> para así, terminar de trabajar con los valores <b>más 
* significativos</b> y obtener los números ordenados. 
* 
* <p>
* Esta clase permite ordenar archivos con números reales de hasta dos decimales separados por comas y sin 
* espacios en blanco entre cada uno. Los archivos leídos pueden tener cualquier cantidad de claves y, 
* en caso de ser requerido, podrán * generarse a partir del programa <b>generador.py</b> ubicado en la 
* carpeta principal del programa.
* </p>
* 
* <p>
* El método de ordenamiento por distribución consiste en analizar dígitos de forma individual e irlos 
* ordenando mediante el uso de <b>colas</b> trabajadas en 10 archivos auxiliares. Los números que se trabajan
* en cada cola son posteriormente desencolados en un cierto orden específico y se devuelven al archivo 
* original. Tras ser evaluados todos los dísgitos de todos los números, el programa envía los números 
* ordenados al archivo original.
* </p>
* 
* @author Basile Álvarez Andrés, Keller Ascencio Rodolfo, Martínez Jiménez María Fernanda
*/
public class Distribucion {
    String nombreArchivoOriginal;
    int tipoOrdenamiento;
    static int valorRecursivoMaximo=0;
    
    String bloque[];
    String bloqueAux[];
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivoString = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    LinkedList<String> numerosArchivoOriginalString = new LinkedList<>();
    ArrayList<ArrayList<Double>> numerosArchivoOriginalArregloDouble = new ArrayList<>();
    
    ArrayList<String> Cola0 = new ArrayList<>();
    ArrayList<String> Cola1 = new ArrayList<>();
    ArrayList<String> Cola2 = new ArrayList<>();
    ArrayList<String> Cola3 = new ArrayList<>();
    ArrayList<String> Cola4 = new ArrayList<>();
    ArrayList<String> Cola5 = new ArrayList<>();
    ArrayList<String> Cola6 = new ArrayList<>();
    ArrayList<String> Cola7 = new ArrayList<>();
    ArrayList<String> Cola8 = new ArrayList<>();
    ArrayList<String> Cola9 = new ArrayList<>();
    
    static String Q0 = "Q0.txt";
    static String Q1 = "Q1.txt";
    static String Q2 = "Q2.txt";
    static String Q3 = "Q3.txt";
    static String Q4 = "Q4.txt";
    static String Q5 = "Q5.txt";
    static String Q6 = "Q6.txt";
    static String Q7 = "Q7.txt";
    static String Q8 = "Q8.txt";
    static String Q9 = "Q9.txt";
    
    /**
     * Método constructor de los objetos de la clase. Se pasa como parámetro el nombre del archivo que busca ordenarse (String)
     * con su debida extensión (.txt),así como un número entero que indica el tipo de ordenamiento a realizar (1 para ascendente o 2 para descendente).
     * @param nombre
     * @param tipoOrdenamiento 
     */
    Distribucion(String nombre, int tipoOrdenamiento){
        this.tipoOrdenamiento = tipoOrdenamiento;
        this.nombreArchivoOriginal = nombre;
    }
    
    /**
     * Este método de tipo <b>void</b> recibe como parámetros el nombre de nuestro archivo a crear con su debida extensión (.txt).
     * Dentro de este método, se va a crear un nuevo archivo en caso de que éste no exista, permitiéndonos hacer uso de archivos
     * auxiliares al momento de realizar el ordenamiento externo.
     */
    public void crearArchivo(String nombre){
        try {
            FileWriter file = new FileWriter(nombre,false);
            file.close();
        } catch (IOException e) {
            System.out.println("ERROR AL CREAR EL ARCHIVO");
        }

    }
     
    /**
     * Este método de tipo <b>void</b> no recibe ningún parámetro, sin embargo, se hace uso del atributo <b>nombre</b> 
     * que representa al nombre del archivo original, de donde se extraen los valores a ordenar, y a partir 
     * de este atributo, se leerán los números que se encuentren dentro de este archivo.
     * Utiliza un único ciclo for para recorrer los elementos dentro del archivo original, éstos son almacenados y ubica sus elementos 
     * en el arreglo de cadenas <b>numeros</b>, para posteriormente ubicarlo en el ArrayList <b>numerosDouble</b>.
     * Finalmente, agrega los elementos leídos al ArrayList de cadenas <b>numerosArchivoOriginalString</b>, para posteriormente
     * volver a trabajar con todos los elementos a los que se han procesado por el análisis de alguna de las posiciones de sus 
     * dígitos individuales.
     */
    public void lecturaOriginal(){
        String numeros[];
        numerosDouble.clear();
        numerosArchivoOriginalString.clear();
        try{
            FileReader lArchivo = new FileReader(nombreArchivoOriginal);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }
            }
            for(int i=0; i<numerosDouble.size(); i++){
                numerosArchivoOriginalString.add(numerosDouble.get(i).toString());
            }
            FileWriter original = new FileWriter(nombreArchivoOriginal,false);
            original.write("");
            original.close();
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    /**
     * Este método de tipo <b>void</b> no recibe ningún parámetro, sin embargo, mediante el uso de dos ciclos for anidados 
     * se va recorriendo cada uno de los numeros que se tienen en la lista ligada de números y se va evaluando la longitud 
     * de estos números, para que, de este modo, se determine cuál es el valor máximo recursivo, es decir, el número total 
     * de veces que se requerirá hacer una evaluación para cada uno de los dígitos con los que cuenta un número. Como esta 
     * evaluación se debe realizar para todos los dígitos de todos los números, este ciclo se debe repetir tantas veces 
     * como es el número de dígitos del número más largo.
     * Para esto, mediante un if se va evaluando el valor recursivo máximo y en caso de encontrar un número que contiene más 
     * dígitos, se modificará el atributo <b>ValorRecursivoMaximo</b> a un nuevo valor que indique el tamaño del número más
     * grande evaluado.
     */
    public void ValorRecursivoMaximo(){
        for(int t=0; t<numerosArchivoOriginalString.size(); t++){
            for(int q=0; q<numerosArchivoOriginalString.get(t).length(); q++){
                if(valorRecursivoMaximo<numerosArchivoOriginalString.get(t).length()){
                    valorRecursivoMaximo = numerosArchivoOriginalString.get(t).length()+2;
                }
            }
        }
    }
    
    /**
     * Este método de tipo <b>void</b> no recibe ningún parámetro, sin embargo, hace uso de arreglo de arreglos de tipo double
     * donde se van a almacenar cada uno de los dígitos de los números a ordenar.
     * 
     * <p>
     * Dentro de este método, se va a trabajar con el ArrayList <b>"numerosArchivoOriginalString"</b> que contiene todos los valores
     * que se desean ordenar, cada uno de estos valores será almacenado dentro de una variable temporal para posteriormente ir 
     * evaluando cada uno de los dígitos contenidos por este número y almacenarlos en cada una de las posiciones de la lista de
     * arreglo de arreglos, donde se va a uniformizar la longitud de cada uno de los números completando hasta dos decimales de 
     * cada número y añadiendo dígitos cero al iniciar cada uno de los valores que no cuenten con la longitud <b>"valorRecursivoMaximo"</b>
     * para que, de este modo, todos los números cuenten con la misma cantidad de dígitos a evaluar sin la necesidad de afectar 
     * el valor de los números.
     * </p>
     */
    public void ArregloDeArreglos(){
        String temporal;
        String temporalDeTemporada;
        numerosArchivoOriginalArregloDouble.clear();
        for(int t=0; t<numerosArchivoOriginalString.size(); t++){
            numerosArchivoOriginalArregloDouble.add(new ArrayList<>());
            temporal = numerosArchivoOriginalString.get(t);
            numerosArchivoOriginalArregloDouble.get(t).add(Double.parseDouble(temporal));
            System.out.println("Valor " +numerosArchivoOriginalString.get(t));
            temporal = numerosArchivoOriginalArregloDouble.get(t).toString();
            for(int k=1; k<temporal.length()-1;k++){
                numerosArchivoOriginalArregloDouble.get(t).add(new Double(0));
                System.out.println("Arreglo Enteros "+numerosArchivoOriginalArregloDouble.get(t));
                if(temporal.charAt(k) != 46){
                    temporalDeTemporada = String.valueOf(temporal.charAt(k));
                    numerosArchivoOriginalArregloDouble.get(t).set(k,Double.parseDouble(temporalDeTemporada));
                }
                if((temporal.charAt(k) == 46) && temporal.toString().length()==k+3){
                    numerosArchivoOriginalArregloDouble.get(t).add(0.0);
                }
            }
            while(numerosArchivoOriginalArregloDouble.get(t).size()<valorRecursivoMaximo){
                numerosArchivoOriginalArregloDouble.get(t).add(1,0.0);
                System.out.println("Arreglo Enteros "+numerosArchivoOriginalArregloDouble.get(t));
            }
        }
    }
    
    /**
     * Este método de tipo <b>void</b> recibe como parámetro el número de la posición del dígito que se va a evaluar dentro de
     * la lista de arreglo de arreglos. Dentro de este método, se va a evaluar una posición específica de cada uno de los números, 
     * para que, de esta forma, dependiendo del valor del dígito evaluado se almacene cada uno de los números a ordenar dentro de 
     * uno de los archivos auxiliares o colas, mediante el uso de un switch-case.
     * @param posicionVerificando el número de la posición del dígito dentro del número que se va a evaluar.
     */
    public void radixSort(int posicionVerificando){
        double valor;
        try{
            
            FileReader lf0 = new FileReader(Q0);
            FileReader lf1 = new FileReader(Q1);
            FileReader lf2 = new FileReader(Q2);
            FileReader lf3 = new FileReader(Q3);
            FileReader lf4 = new FileReader(Q4);
            FileReader lf5 = new FileReader(Q5);
            FileReader lf6 = new FileReader(Q6);
            FileReader lf7 = new FileReader(Q7);
            FileReader lf8 = new FileReader(Q8);
            FileReader lf9 = new FileReader(Q9);
            
            BufferedReader blf0 = new BufferedReader(lf0);
            BufferedReader blf1 = new BufferedReader(lf1);
            BufferedReader blf2 = new BufferedReader(lf2);
            BufferedReader blf3 = new BufferedReader(lf3);
            BufferedReader blf4 = new BufferedReader(lf4);
            BufferedReader blf5 = new BufferedReader(lf5);
            BufferedReader blf6 = new BufferedReader(lf6);
            BufferedReader blf7 = new BufferedReader(lf7);
            BufferedReader blf8 = new BufferedReader(lf8);
            BufferedReader bf9 = new  BufferedReader(lf9);
            
            FileWriter f0 = new FileWriter(Q0,false);
            FileWriter f1 = new FileWriter(Q1,false);
            FileWriter f2 = new FileWriter(Q2,false);
            FileWriter f3 = new FileWriter(Q3,false);
            FileWriter f4 = new FileWriter(Q4,false);
            FileWriter f5 = new FileWriter(Q5,false);
            FileWriter f6 = new FileWriter(Q6,false);
            FileWriter f7 = new FileWriter(Q7,false);
            FileWriter f8 = new FileWriter(Q8,false);
            FileWriter f9 = new FileWriter(Q9,false);
            
            for(int i=0; i<numerosArchivoOriginalArregloDouble.size(); i++){
                System.out.println("Valor verificando " + numerosArchivoOriginalArregloDouble.get(i).get(0).toString());
                System.out.println("Posicion Verificando " + posicionVerificando);
                valor = numerosArchivoOriginalArregloDouble.get(i).get(posicionVerificando);
                switch((int)valor){
                    case 0:
                        f0.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f0.write(",");
                        break;
                    case 1:
                        f1.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f1.write(",");
                        break;
                    case 2:
                        f2.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f2.write(",");
                        break;
                    case 3:
                        f3.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f3.write(",");
                        break;
                    case 4:
                        f4.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f4.write(",");
                        break;
                    case 5:
                        f5.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f5.write(",");
                        break;
                    case 6:
                        f6.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f6.write(",");
                        break;
                    case 7:
                        f7.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f7.write(",");
                        break;
                    case 8:
                        f8.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f8.write(",");
                        break;
                    case 9:
                        f9.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                        f9.write(",");
                        break;     
                }
            }
            f0.close();
            f1.close();
            f2.close();
            f3.close();
            f4.close();
            f5.close();
            f6.close();
            f7.close();
            f8.close();
            f9.close();
        }catch(IOException e){
            System.out.println("ERROR DE ARCHIVO");
        }
    }
    
    /**
     * Este método de tipo <b>void</b> recibe como parámetro un ArrayList de tipo String que contiene todos los números
     * provenientes de alguna de los <b>archivos auxiliares o colas</b>, para posteriormente, almacenar dichos números en el 
     * <b>archivo original</b>. En este método, se escriben los valores recabados de las colas en el archivo original, donde
     * el archivo original no es sobrescrito, por lo que se conservan todos los valores que se encuentren registrados 
     * dentro de este archivo.
     * @param cola el nombre del ArrayList de donde se leerán los elementos que se van a almacenar en el archivo original.
     */
    public void vaciarColas(ArrayList<String> cola){
        try{
            FileWriter original = new FileWriter(nombreArchivoOriginal,true);
            while(!cola.isEmpty()){
                original.write(cola.remove(0));
                original.write(",");
            }
            original.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * Este método de tipo <b>void</b> no recibe ningún parámetro, sin embargo, manda llamar al método <b>"lecturaArchivo"</b> donde
     * se va a leer cada uno de los archivos auxiliares que se están utilizando como colas, se van a obtener los elementos de
     * cada archivo siendo almacenados en un <b>ArrayList de tipo String</b> y después de haber almacenado cada uno de los archivos
     * auxiliares, se va a mandar a llamar a la función <b>"vaciarColas"</b> que recibirá como parámetro el nombre del parámetro que 
     * contiene los valores numéricos de cada cola y almacenarán la información de manera ordenada dentro del archivo original.
     * 
     * <p>
     * Al ser esta un método que nos sirve para el ordenamiento externo de números de forma ascendente, primero se vaciarán
     * los datos provenientes de la cola "0", para continuar con la cola "1", cola "2" y así sucesivamente hasta llegar a la 
     * cola "9". El archivo original no es sobreescrito, sino que los números provenientes de cada cola son almacenados unos 
     * tras otros sin perder ninguno de ellos.
     * </p>
     */
    public void pasarAOriginalAscendente(){
        Cola0 = lecturaArchivo(Q0, "0");
        Cola1 = lecturaArchivo(Q1, "1");
        Cola2 = lecturaArchivo(Q2, "2");
        Cola3 = lecturaArchivo(Q3, "3");
        Cola4 = lecturaArchivo(Q4, "4");
        Cola5 = lecturaArchivo(Q5, "5");
        Cola6 = lecturaArchivo(Q6, "6");
        Cola7 = lecturaArchivo(Q7, "7");
        Cola8 = lecturaArchivo(Q8, "8");
        Cola9 = lecturaArchivo(Q9, "9");
        vaciarColas(Cola0);
        vaciarColas(Cola1);
        vaciarColas(Cola2);
        vaciarColas(Cola3);
        vaciarColas(Cola4);
        vaciarColas(Cola5);
        vaciarColas(Cola6);
        vaciarColas(Cola7);
        vaciarColas(Cola8);
        vaciarColas(Cola9);
    }
    
    /**
     * Este método de tipo <b>void</b> no recibe ningún parámetro, sin embargo, manda llamar al método <b>"lecturaArchivo"</b> donde
     * se va a leer cada uno de los archivos auxiliares que se están utilizando como colas, se van a obtener los elementos de
     * cada archivo siendo almacenados en un <b>ArrayList de tipo String</b> y después de haber almacenado cada uno de los archivos
     * auxiliares, se va a mandar a llamar a la función <b>"vaciarColas"</b> que recibirá como parámetro el nombre del parámetro que 
     * contiene los valores numéricos de cada cola y almacenarán la información de manera ordenada dentro del archivo original.
     * 
     * <p>
     * Al ser esta un método que nos sirve para el ordenamiento externo de números de forma descendente, primero se vaciarán
     * los datos provenientes de la cola "9", para continuar con la cola "8", cola "7" y así sucesivamente hasta llegar a la 
     * cola "0". El archivo original no es sobreescrito, sino que los números provenientes de cada cola son almacenados unos 
     * tras otros sin perder ninguno de ellos.
     * </p>
     */
    public void pasarAOriginalDescendente(){
        Cola0 = lecturaArchivo(Q0, "0");
        Cola1 = lecturaArchivo(Q1, "1");
        Cola2 = lecturaArchivo(Q2, "2");
        Cola3 = lecturaArchivo(Q3, "3");
        Cola4 = lecturaArchivo(Q4, "4");
        Cola5 = lecturaArchivo(Q5, "5");
        Cola6 = lecturaArchivo(Q6, "6");
        Cola7 = lecturaArchivo(Q7, "7");
        Cola8 = lecturaArchivo(Q8, "8");
        Cola9 = lecturaArchivo(Q9, "9");
        vaciarColas(Cola9);
        vaciarColas(Cola8);
        vaciarColas(Cola7);
        vaciarColas(Cola6);
        vaciarColas(Cola5);
        vaciarColas(Cola4);
        vaciarColas(Cola3);
        vaciarColas(Cola2);
        vaciarColas(Cola1);
        vaciarColas(Cola0);
    }
    
    /**
     * Este método con retorno de tipo <b>ArrayList</b> toma como parámetro el nombre del archivo
     * que se lee así como el nombre con el cual se imprimirá más tarde el bloque al que pertenece.
     * Utiliza un único ciclo for para recorrer los elementos dentro de los archivos auxiliares o colas
     * que utilizamos como apoyo en el ordenamiento externo e imprimir dichos elementos en pantalla. 
     * Finalmente, devuelve el ArrayList <b>bloqueArchivoString</b> el cual contiene los elementos mencionados
     * anteriormente. 
     * @param archivo el nombre del archivo que se va a leer. 
     * @param nombreArchivo el nombre con el cual se quiere imprimir el bloque del archivo. 
     * @return regresa el ArrayList de tipo String <b>bloqueArchivoString</b> el cual contiene el bloque 
     * leído del archivo auxiliar. 
     */
    public ArrayList<String> lecturaArchivo(String archivo, String nombreArchivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileWriter arch = new FileWriter(archivo,true);
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split(",");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueArchivoString.add((bloque[i]));
                    }
                }  
                System.out.println("Bloque " + nombreArchivo);
                for(String d : bloqueArchivoString){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux.close();
            arch.write("");
            arch.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
   
    /**
     * En este método de tipo <b>void</b> se realizan las operaciones necesarias para ir ordenando los elementos
     * dentro del archivo original en un orden específico. 
     * 
     * <p>
     * Lo primero que se realica es crear los 10 archivos auxiliares que vamos a utilizar para realizar el ordenamiento y trabajarlo 
     * como colas, posteriormente, se va a realizar la lectura del archivo original y todos los valores se van a agregar a un ArrayList,
     * para posteriormente analizar los valores y conocer cual es el máximo número de dígitos con el que vamos a trabajar a lo largo 
     * del ordenamiento mediante el uso de la función <b>"ValorRecursivoMaximo"</b> que va analizando el tamaño de los números trabajados y 
     * encuentra el valor máximo de éstos.
     * </p>
     * 
     * <p>
     * Mediante el uso del método <b>"ArregloDeArreglos"</b> se va a formar un arreglo de arreglos de números enteros donde dentro de cada 
     * posición se va a colocar cada dígito de los números trabajados. Dentro de un ciclo for, se va a recorrer cada uno de los dígitos de cada número y
     * gracias al uso de método <b>"radixSort"</b> se va a ir colocando cada número dentro de una cola dependiendo del valor del dígito en la posición verificando.
     * </p>
     * 
     * <p>
     * En caso de que se decida ordenar en forma ascendente, se llama al método <b>"pasarAOriginalAscendente"</b> donde se van a ir colocando los números de las colas
     * comenzando a vaciar la cola "0" y terminando en la cola "9"; en caso de que se decida ordenar de forma descendente, se va a empezar a vaciar la cola "9"
     * para finalmente terminar con los números contenidos dentro de la cola "0". Gracias al uso de un if, se va a verificar la posición de los dígitos de los 
     * números con la que se está trabajando, en caso de encontrarse desde la primera hasta la penúltima posición a verificar, se va a leer el archivo original 
     * y se va a pasar sus valores a un nuevo arreglo de arreglos de enteros mediante el método <b>"ArregloDeArreglos"</b>, en caso de encontrarse en la última posición 
     * a verificar, este procedimiento no se realizará debido a que los números ya se encuentran ordenados dentro del archivo original.
     * </p> 
     */
    public void ordenamiento(){
        crearArchivo(Q0);
        crearArchivo(Q1);
        crearArchivo(Q2);
        crearArchivo(Q3);
        crearArchivo(Q4);
        crearArchivo(Q5);
        crearArchivo(Q6);
        crearArchivo(Q7);
        crearArchivo(Q8);
        crearArchivo(Q9);
        lecturaOriginal();
        ValorRecursivoMaximo();
        ArregloDeArreglos();
        for(int basileKellerMartinez=valorRecursivoMaximo-1; basileKellerMartinez>1; basileKellerMartinez--){
            radixSort(basileKellerMartinez);
            if(tipoOrdenamiento==1)
                pasarAOriginalAscendente();
            else
                pasarAOriginalDescendente();
            if(basileKellerMartinez!=2){
                lecturaOriginal();
                ArregloDeArreglos();
            }
        }
        bloqueArchivoOriginalString = lecturaArchivo(nombreArchivoOriginal, "Original");
    }
        
}