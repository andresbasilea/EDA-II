package ordenamientoexterno;

import java.util.*;
import java.io.*;

/**
* Implementa el método de ordenamiento externo por <b>mezcla equilibrada</b>. El método de ordenamiento
* por mezcla equilibrada implementado en esta clase permite ordenar archivos con números
* reales de hasta dos decimales separados por comas y sin espacios en blanco entre cada uno.
* Los archivos leídos pueden tener cualquier cantidad de claves y, en caso de ser requerido, podrán 
* generarse a partir del programa <b>generador.py</b> ubicado en la carpeta principal del programa.
* 
* <p>
* El método de ordenamiento por mezcla equilibrada consiste en realizar <b>particiones</b> o <b>bloques</b>
* tomando secuencias de máxima longitud (conocidas como "natural runs"). Estas secuencias de máxima longitud son 
* ubicadas en 2 archivos auxiliares "AuxiliarMezclaEquilibrada1.txt" y "AuxiliarMezclaEquilibrada2.txt", de donde serán
* leídas, ordenadas mediante un "merge" y ubicadas nuevamente en el archivo original, repitiendo el proceso hasta 
* que se obtenga una secuencia totalmente ordenada de números (ya sea de manera ascendente o descendente).
* </p>
* 
* @author Basile Álvarez Andrés, Keller Ascencio Rodolfo, Martínez Jiménez María Fernanda
*/
public class MezclaEquilibrada {
    String nombreArchivoOriginal;
    int tipoOrdenamiento;
    
    String bloque[];
    String numeros[];    
    String bloqueAux[];    
    String bloque1Original[];    
    String bloque1OriginalAux[];
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivo1String = new ArrayList<>();
    ArrayList<String> bloqueArchivo2String = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    
    static String nomAux1 = "AuxiliarMezclaEquilibrada1.txt";
    static String nomAux2 = "AuxiliarMezclaEquilibrada2.txt";
    
    /**
     * Método constructor de los objetos de la clase. Se pasa como parámetro el nombre del archivo que busca ordenarse (String)
     * con su debida extensión (.txt),así como un número entero que indica el tipo de ordenamiento a realizar (1 para ascendente o 2 para descendente).
     * El método constructor utiliza el nombre del archivo pasado como parámetro para abrirlo, leerlo y guardar todos los números
     * encontrados en él dentro de un arreglo de cadenas, <b>"numeros"</b>. Una vez encontrados allí, los números son pasados a un
     * ArrayList de elementos Double, <b>numerosDouble</b>, para su posterior uso durante la ejecución del programa. 
     * @param archivo
     * @param tipoOrdenamiento 
     */
    MezclaEquilibrada(String archivo, int tipoOrdenamiento){
        this.nombreArchivoOriginal = archivo;
        this.tipoOrdenamiento = tipoOrdenamiento;  
        try{
            FileReader lArchivo = new FileReader(nombreArchivoOriginal);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }      
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    /**
     * Este método de tipo <b>void</b> sin parámetros crea los dos archivos auxiliares del programa y divide 
     * a los elementos del ArrayList <b>numerosDouble</b> en bloques tomando secuencias ordenadas de máxima longitud de números 
     * y colocándolas en los archivos auxiliares conforme van apareciendo (la primer secuencia se ubica en el primer archivo, 
     * la segunda en el segundo, la tercera en el primero y así sucesivamente hasta terminar con todos los números dentro de <b>numerosDouble</b>).
     */
    public void bloques(){
        try{
            FileWriter archivoOriginal = new FileWriter(nombreArchivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1;
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }
            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    /**
     * Este método con retorno de tipo <b>ArrayList</b> toma como parámetro el nombre del archivo
     * auxiliar que se lee así como el nombre con el cual se imprimirá más tarde el bloque al que pertenece.
     * Utiliza dos ciclos for anidados para recorrer los elementos dentro del archivo auxiliar número 1 ó 2 
     * e imprimir dichos elementos en pantalla. 
     * Finalmente, devuelve el ArrayList <b>bloqueArchivoString</b> el cual contiene los elementos mencionados
     * anteriormente. 
     * @param archivo el nombre del archivo que se va a leer. 
     * @param nombreArchivo el nombre con el cual se quiere imprimir el bloque del archivo. 
     * @return regresa el ArrayList de tipo String <b>bloqueArchivoString</b> el cual contiene el bloque 
     * leído del archivo auxiliar. 
     */
    public ArrayList<String> lecturaArchivoAuxiliar(String archivo, String nombreArchivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split("/");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueAux = bloque[i].split(",");
                        for(int j=0; j<bloqueAux.length;j++){
                            bloqueArchivoString.add((bloqueAux[j]));
                        }
                        bloqueArchivoString.add("/");
                    }
                }  
                System.out.println("Bloque " + nombreArchivo);
                for(String d : bloqueArchivoString){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
    
    /**
     * Este método de tipo <b>void</b> permite escribir de nuevo los elementos dentro de los bloques de los 
     * archivos uno y dos guardados en los ArrayList de tipo String <b>bloqueArchivo1String</b> y <b>bloqueArchivo2String</b>,
     * respectivamente. Los bloques son almacenados en el archivo original siguiendo el procedimiento: 
     * Se leen ambos archivos. Se compara el primer elemento del primer bloque con el primer elemento del segundo bloque.
     * El mayor de ellos es colocado en el archivo original y removido de su respectivo bloque. Se continúa hasta que alguno de los bloques
     * se encuentre vacío y finalmente se escriben en el archivo original los elementos restantes del bloque no vacío. 
     */
    public void escrituraBloquesArchivoOriginal(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombreArchivoOriginal,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))<Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo2String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * Este método de tipo <b>void</b> lee el archivo original nuevamente y ubica sus elementos 
     * en el arreglo de cadenas <b>bloqueOriginal</b>. Agrega los elementos leídos al ArrayList 
     * de cadenas <b>bloqueArchivoOriginalString</b> para su impresión en pantalla y su escritura 
     * en los archivos auxiliares 1 y 2 a manera de bloques.
     */
    public void leerArchivoOriginalPasarAAuxiliares(){
        try{
            FileReader archivoOriginal = new FileReader(nombreArchivoOriginal);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);
            FileWriter aux1 = new FileWriter(nomAux1,false);
            FileWriter aux2 = new FileWriter(nomAux2,false);
            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
                System.out.println("BloqueOriginal");
                for(String d : bloqueArchivoOriginalString){
                    System.out.println(d);
                }
                System.out.println();
                while(!bloqueArchivoOriginalString.isEmpty()){
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        aux1.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux1.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux1.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)!="/"){
                        aux2.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux2.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux2.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
            }
            bArchivoOriginal.close();
            aux1.close();
            aux2.close();
        }catch(IOException e){
            System.out.println("ERROR¿?");
        } 
    }
    
    /**
     * Este método de tipo <b>boolean</b> que no toma parámetros lee el ArrayList de cadenas 
     * <b>bloqueArchivoOriginalString</b> después de realizar el "merge" de los archivos auxiliares
     * y verifica si dentro de éste se encuentra el símbolo "/", el cual indica la división entre dos bloques
     * de números. El archivo se encontrará ordenado cuando haya únicamente uno o ningún "/" en el ArrayList 
     * leído. 
     * @return <b>true</b> en caso de que el archivo se encuentre ordenado o <b>false</b> en caso contrario. 
     */
    public boolean verificaOrdenamiento(){
        boolean verificaOrdenamiento = true;
        int contadLasLineas = 0;
        for(int m=0; m<bloqueArchivoOriginalString.size(); m++){
            if(bloqueArchivoOriginalString.get(m)=="/"){  
                contadLasLineas++;
            }
        } 
        if(contadLasLineas==1||contadLasLineas==0){
            verificaOrdenamiento = true;
        }
        else{
            verificaOrdenamiento=false;
        }
        bloqueArchivoOriginalString.clear();
        return verificaOrdenamiento;
    }
    
    /**
     * Este método de tipo <b>void</b> que no recibe ningún parámetro permite leer el archivo original
     * y separar los elementos a partir de "/" en un bloque <b>bloque1Original</b>. En caso de que alguna 
     * posición "i" del bloque sea diferente de <b>null</b>, se escribe en <b>bloqueOriginalAux</b> el valor 
     * en la posición "i" del bloque original dividido por ",".
     * 
     */
    public void lecturaArchivoOriginal(){
        try{
            FileReader archivoOriginal = new FileReader(nombreArchivoOriginal);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);
            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
            }
            bArchivoOriginal.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * En este método de tipo <b>void</b> que no recibe ningún parámetro, se realiza la división de
     * bloques de manera descendente a partir de la lectura del archivo original. La división en bloques
     * se realiza a partir de secuencias ordenadas (en orden descendente) de máxima longitud y escritas 
     * en los archivos auxiliares 1 y 2 (de igual manera que en el método "bloques".
     */
    public void bloquesDescendente(){
        try{
            FileWriter archivoOriginal = new FileWriter(nombreArchivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)<numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1; 
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)<numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }
            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    /**
     * En este método de tipo <b>void</b> que no recibe ningún parámetro, se realiza la escritura de los
     * bloques de secuencias máximas de longitud en orden descendente ubicados en los archivo auxiliares 1
     * y 2 en el archivo original, separando cada elemento con "," y escrbiendo un "/" al finalizar el "merge"
     * de los bloques de los archivos auxiliares.  
     */
    public void escrituraBloquesArchivoOriginalDescendente(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombreArchivoOriginal,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))>Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                } 
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo1String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * En este método de tipo <b>void</b> se realizan las operaciones necesarias para ordenar los elementos
     * dentro del archivo original en un orden específico. En caso de que se decida ordenar en forma 
     * ascendente, se llama a los métodos "lecturaArchivoAuxiliar" (1 y 2), "escrituraBloquesArchivoOriginal", 
     * "leerArchivoOriginalPasarAAuxiliares" y "lecturaArchivoOriginal" dentro de un ciclo <b>do-while</b> que se
     * realiza mientras el método "verificaOrdenamiento" devuelva el valor "false" (indicando que el archivo no se encuentra
     * ordenado todavía).
     * <p>En caso de que se decida ordenar de manera descendente, primero se llama al método "bloquesDescendente"
     * para generar los bloques en orden descendente. Dentro de un ciclo <b>do-while</b> se leen los archivos auxiliares 1 y 2
     * utilizando el método "lecturaArchivoAuxiliar", se escribe sobre el archivo original utilizando "escrituraBloquesArchivoOriginalDescendente",
     * se lee el archivo original y se pasa a los auxiliares nuevamente hasta que no se cumpla la condición 
     * "verificaOrdenamiento() == false".</p>
     */
    public void ordenamiento(){
        if(tipoOrdenamiento==1){
            bloques();
            do{
                bloqueArchivo1String = lecturaArchivoAuxiliar(nomAux1, "1");
                bloqueArchivo2String = lecturaArchivoAuxiliar(nomAux2, "2");
                escrituraBloquesArchivoOriginal();
                leerArchivoOriginalPasarAAuxiliares();
                lecturaArchivoOriginal();
            }while(verificaOrdenamiento()==false);            
        }
        
        if(tipoOrdenamiento == 2){
           bloquesDescendente();
            do{
                bloqueArchivo1String = lecturaArchivoAuxiliar(nomAux1, "1");
                bloqueArchivo2String = lecturaArchivoAuxiliar(nomAux2, "2");
                escrituraBloquesArchivoOriginalDescendente();
                leerArchivoOriginalPasarAAuxiliares();
                lecturaArchivoOriginal();
            }while(verificaOrdenamiento()==false); 
        }
    }
    
}
