package practica6basilekeller;
import java.util.*;
import java.lang.ClassCastException;
public class GrafoPonderadoPrimm {
    int V; 
    LinkedList<ListaNodosAdyacentesVertice> listaAdyacentes = new LinkedList<ListaNodosAdyacentesVertice>(); 
    ArrayList<NodoAdyacente> colaPrioridad = new ArrayList<>();
    LinkedList<NodoAdyacente> arbolExpansion = new LinkedList<>();
    
    GrafoPonderadoPrimm(int v){
        this.V = v;  
        for (int i=0; i<v; ++i){
            listaAdyacentes.add(new ListaNodosAdyacentesVertice()); 
        }
    }
    
    void addEdgeNoDirigido(int origen ,int destino, int valor){
        this.listaAdyacentes.get(origen).agregarNodo(new NodoAdyacente(origen,destino, valor));
        this.listaAdyacentes.get(destino).agregarNodo(new NodoAdyacente(destino, origen, valor));
    } 
    
    void imprimirListaAdyacentes(){
        for(int v = 0; v < V; v++){
            for(int y = 0; y<listaAdyacentes.get(v).nodosadyacentes.size(); y++){
                System.out.println("Origen " + v);
                System.out.println("Destino " + this.listaAdyacentes.get(v).nodosadyacentes.get(y).nodoDestino);
                System.out.println("Valor " + this.listaAdyacentes.get(v).nodosadyacentes.get(y).valor);
                System.out.println();
            }
        }
    }

    void printGraph(GrafoPonderadoPrimm graph){
        System.out.println("Árbol de Expansión ");
            for(NodoAdyacente p : arbolExpansion){
                p.imprimir();
            }
        System.out.println("\n");
    }
    
    void algoritmoPrimm(int v){
        boolean visited[] = new boolean[V];
        primmUtil(v,visited);
    }
    
    void primmUtil(int v, boolean visited[]){
            NodoAdyacente trabajado = new NodoAdyacente();
            NodoAdyacente intercambio1 = new NodoAdyacente();
            NodoAdyacente intercambio2 = new NodoAdyacente();
            visited[v]=true;
            while(!listaAdyacentes.get(v).nodosadyacentes.isEmpty()){
                colaPrioridad.add(listaAdyacentes.get(v).nodosadyacentes.pollFirst());
            }
            while(!colaPrioridad.isEmpty()){
                for(int e=0; e<colaPrioridad.size();e++){
                    for (int j = 0; j < colaPrioridad.size()-e-1; j++) 
                        if(colaPrioridad.get(j).valor > colaPrioridad.get(j+1).valor){ 
                            intercambio1 = colaPrioridad.get(j);
                            intercambio2 = colaPrioridad.get(j+1);
                            colaPrioridad.set(j,intercambio2); 
                            colaPrioridad.set(j+1,intercambio1); 
                        } 
                        
                }
                trabajado = colaPrioridad.remove(0);
                if(visited[trabajado.nodoDestino] == false){
                    arbolExpansion.add(trabajado);
                    visited[trabajado.nodoDestino] = true;
                    while(!listaAdyacentes.get(trabajado.nodoDestino).nodosadyacentes.isEmpty()){
                        colaPrioridad.add(listaAdyacentes.get(trabajado.nodoDestino).nodosadyacentes.pollFirst());
                    }
                }
                primmUtil(trabajado.nodoDestino, visited);
            }
    }
    
    
}