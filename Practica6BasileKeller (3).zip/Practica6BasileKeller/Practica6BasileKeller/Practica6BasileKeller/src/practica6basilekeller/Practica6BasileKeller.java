package practica6basilekeller;
import java.util.*;

public class Practica6BasileKeller {

    public static void main(String[] args) {
        int V = 5;
        int i,aristas,v,w, opcion, inicio;
        boolean verifica=true;
        Scanner sc= new Scanner(System.in);
        Graph graph = new Graph(V);
        Graph grafoDFS = new Graph(8);
        graph.addEdgeNoDirigido(0, 1);
        graph.addEdgeNoDirigido(0, 4);
        graph.addEdgeNoDirigido(1, 2);
        graph.addEdgeNoDirigido(1, 3);
        graph.addEdgeNoDirigido(1, 4);
        graph.addEdgeNoDirigido(2, 3);
        graph.addEdgeNoDirigido(3, 4);
        graph.printGraph(graph);
        //Para Graph DFS
        grafoDFS.addEdgeNoDirigido(1, 5);
        grafoDFS.addEdgeNoDirigido(5, 4);
        grafoDFS.addEdgeNoDirigido(5, 7);
        grafoDFS.addEdgeNoDirigido(4, 7);
        grafoDFS.addEdgeNoDirigido(7, 3);
        grafoDFS.addEdgeNoDirigido(0, 2);
        grafoDFS.addEdgeNoDirigido(0, 4);
        grafoDFS.addEdgeNoDirigido(0, 6);
        while(verifica){
            System.out.println("\n\nBienvenido al sistema de uso de grafos");
            System.out.println("Ingrese la opción del grafo que desea utilizar a continuación");
            System.out.println("1) Crear grafos no dirigidos.");
            System.out.println("2) Crear grafos dirigidos.");
            System.out.println("3) Crear grafos ponderados.");
            System.out.println("4) Breadth First Search. ");
            System.out.println("5) Depth First Search. ");
            System.out.println("6) Algoritmo de Primm. ");
            System.out.println("7) Salir.");
            opcion = sc.nextInt();
            cls();
            switch(opcion){
                case 1:
                    cls();
                    System.out.println(" *** Bienvenido a la sección de creación de grafos no dirigidos *** ");
                    System.out.println("Indique el tamaño o número de vértices de su grafo ");
                    V = sc.nextInt();
                    cls();
                    Graph graphusr = new Graph(V);
                    System.out.println("Ahora indique el número de aristas que desea crear dentro de su grafo");
                    aristas = sc.nextInt();
                    for(i=0; i<aristas;i++){
                        cls();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo inicial de la arista");
                        v= sc.nextInt();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo final de la arista");
                        w=sc.nextInt();
                        graphusr.addEdgeNoDirigido(v,w);
                    }
                    cls();
                    System.out.println("A continuación se mostrará su grafo");
                    graphusr.printGraph(graphusr);
                    graphusr.printGraphMatrizAdyacencia(graphusr); 
                    break;
                    
                case 2:
                    System.out.println(" *** Bienvenido a la sección de creación de grafos dirigidos *** ");
                    System.out.println("Indique el tamaño o número de vértices de su grafo ");
                    V = sc.nextInt();
                    cls();
                    Graph graphusrd = new Graph(V);
                    System.out.println("Ahora indique el número de aristas que desea crear dentro de su grafo");
                    aristas = sc.nextInt();
                    for(i=0; i<aristas;i++){
                        cls();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo inicial de la arista");
                        v= sc.nextInt();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo final de la arista");
                        w=sc.nextInt();
                        graphusrd.addEdgeDirigido(v,w);
                    }
                    cls();
                    System.out.println("A continuación se mostrará su grafo");
                    graphusrd.printGraph(graphusrd);
                    graphusrd.printGraphMatrizAdyacencia(graphusrd);
                    break;
                    
                case 3:
                    System.out.println(" *** Bienvenido a la sección de creación de grafos dirigidos ponderados *** ");
                    System.out.println("Indique el tamaño o número de vértices de su grafo ");
                    V = sc.nextInt();
                    cls();
                    GrafoPonderado grafoPUsr = new GrafoPonderado(V);
                    System.out.println("Ahora indique el número de aristas que desea crear dentro de su grafo");
                    aristas = sc.nextInt();
                    for(i=0; i<aristas; i++){
                        cls();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo inicial de la arista");
                        v= sc.nextInt();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo final de la arista");
                        w=sc.nextInt();
                        System.out.println("Ingrese el valor de la arista que unirá dichos vértices: ");
                        int valor = sc.nextInt();
                        grafoPUsr.addEdge(v, w, valor);
                    }
                    cls();
                    System.out.println("A continuación se muestra su grafo: ");
                    grafoPUsr.printGraph(grafoPUsr); 
                    break;
                    
                case 4:
                    System.out.println("***Bienvenido a la sección de búsqueda por expansión ***");
                    System.out.println("Se realizará la primera búsqueda en un grafo dirigido...\nIndique el tamaño o número de vértices de su grafo");
                    V = sc.nextInt();
                    cls();
                    Graph grafoBFS = new Graph(V);
                    System.out.println("Ahora indique el número de aristas que desea crear dentro de su grafo");
                    aristas = sc.nextInt();
                    for(i=0; i<aristas; i++){
                        cls();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo inicial de la arista");
                        v= sc.nextInt();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo final de la arista");
                        w=sc.nextInt();
                        grafoBFS.addEdgeDirigido(v, w);
                    }
                    cls();
                    grafoBFS.printGraph(grafoBFS);
                    grafoBFS.printGraphMatrizAdyacencia(grafoBFS);
                    System.out.println("Resultado de la búsqueda para el vértice \"0\" en grafo dirigido ");
                    grafoBFS.BFS(0);
                    if(V>1){
                        System.out.println("\nResultado de la búsqueda para el vértice \"1\" en grafo dirigido");
                        grafoBFS.BFS(1);
                    }
                    System.out.println("\n***Ingrese \"OK\" para continuar: ");
                    sc.next();
                    
                    
                    
                    System.out.println("\n\nSe realizará la segunda búsqueda en un grafo no dirigido...\nIndique el tamaño o número de vértices de su grafo ");
                    V = sc.nextInt();
                    cls();
                    Graph grafoBFS2 = new Graph(V);
                    System.out.println("Ahora indique el número de aristas que desea crear dentro de su grafo");
                    aristas = sc.nextInt();
                    for(i=0; i<aristas;i++){
                        cls();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo inicial de la arista");
                        v= sc.nextInt();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo final de la arista");
                        w=sc.nextInt();
                        grafoBFS2.addEdgeNoDirigido(v,w);
                    }
                    cls();
                    grafoBFS2.printGraph(grafoBFS2);
                    grafoBFS2.printGraphMatrizAdyacencia(grafoBFS2); 
                    System.out.println("Resultado de búsqueda desde vértice 0 en grafo no dirigido: ");
                    grafoBFS2.BFS(0);
                    if(V>1){
                        System.out.println("\nResultado de búsqueda desde vértice 1 en grafo no dirigido: ");
                        grafoBFS2.BFS(1);
                    }
                    break;
                    
                case 5:
                    for(i=0; i<3; i++){
                        System.out.println("Ingrese el vértice de inicio");
                        inicio = sc.nextInt();
                        System.out.println("Lista de vértices visitados en orden DFS:");
                        grafoDFS.DFS(inicio);
                        System.out.println("");
                    }
                    break;
                    
                case 6:
                    System.out.println(" *** Bienvenido a la sección Algoritmo de Primm *** ");
                    System.out.println("Indique el tamaño o número de vértices de su grafo ");
                    V = sc.nextInt();
                    cls();
                    GrafoPonderadoPrimm grafoPrimm = new GrafoPonderadoPrimm(V);
                    System.out.println("Ahora indique el número de aristas que desea crear dentro de su grafo");
                    aristas = sc.nextInt();
                    for(i=0; i<aristas; i++){
                        cls();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo inicial de la arista");
                        v= sc.nextInt();
                        System.out.println("Ingrese el vértice que se encuentra en el extremo final de la arista");
                        w=sc.nextInt();
                        System.out.println("Ingrese el valor de la arista que unirá dichos vértices: ");
                        int valor = sc.nextInt();
                        grafoPrimm.addEdgeNoDirigido(v, w, valor);
                    }
                    System.out.println("Ingrese el nodo desde el cual desea iniciar el Algoritmo de Primm");
                    inicio = sc.nextInt();
                    grafoPrimm.algoritmoPrimm(inicio);
                    grafoPrimm.printGraph(grafoPrimm); 
                    break;
                    
                case 7:
                    verifica=false;
                    break;
                    
                default:
                    System.out.println("Opción incorrecta");
                    break;
            }
        }
    }
    
    public static void cls(){
        for(int i=0; i<80;i++)
            System.out.println("");
    }
}
