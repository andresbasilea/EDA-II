package practica6basilekeller;

import java.util.Iterator; 
import java.util.LinkedList;

public class Graph{
    int V;
    LinkedList<Integer> adjArray[];
    
    Graph(int v){
        V = v;
        adjArray = new LinkedList[v]; 
        for (int i=0; i<v; ++i)
            adjArray[i] = new LinkedList();
    }
    
    void addEdgeNoDirigido(int v,int w){
            adjArray[v].add(w);
            adjArray[w].add(v);
        }
    
    void addEdgeDirigido(int v,int w){
            adjArray[v].add(w);
        }

    void printGraph(Graph graph){
        for(int v = 0; v < graph.V; v++){
            System.out.println("Lista de Adyacencia del vertice "+ v); 
            System.out.println(v);
            for(Integer node: graph.adjArray[v]){
                System.out.print(" -> "+node); 
            }
            System.out.println("\n");
        }
    } 
    
    void printGraphMatrizAdyacencia(Graph graph){
        System.out.println("Matriz de Adyacencia\n");
        for(int v = 0; v < graph.V; v++)
            System.out.print("   " + v);
        System.out.println("");
        for(int v = 0; v < graph.V; v++){
            System.out.print(v);
            for( int u=0; u<graph.V;u++){
                if(graph.adjArray[v].contains(u))
                    System.out.print(" " + " 1 ");
                else
                    System.out.print(" " + " 0 ");
            }
            System.out.println("");
        }
        System.out.println("\n\n");
    }
    
    void BFS(int s){
        boolean visited[] = new boolean[V];
        LinkedList<Integer> queue = new LinkedList<Integer>();
        visited[s]=true;
        queue.add(s);
        while (queue.size() != 0){
            s = queue.poll();
            System.out.print(s+" ");
            
            Iterator<Integer> i = adjArray[s].listIterator();
            while (i.hasNext()){
                int n = i.next();
                if (!visited[n]) {
                    visited[n] = true;
                    queue.add(n);
                }
            } 
        }
    }
    
    void DFSUtil(int v,boolean visited[]){
        visited[v] = true;
        System.out.print(v+" ");
        
        Iterator<Integer> i = adjArray[v].listIterator(); 
        while (i.hasNext()){
            int n = i.next();
            if (!visited[n])
                DFSUtil(n, visited);
            } 
        }

    void DFS(int v){
        boolean visited[] = new boolean[V];
        DFSUtil(v, visited);
    }
    
}