package ordenamientoexterno;
import java.util.*;
import java.io.*;

public class Distribucion {
    /* 10 archivos como colas
    
    
    1) Leer archivo y pasarlo a arreglo. 
    1.1) 
    1.5) verificar mediante bubble sort que el arreglo se encuentre ordenado, en caso de que asi sea, indicar que el archivo ya esta ordenado y salir. 
    2) Hacer arreglo de arreglos y almacenar los String en forma de arreglo 
    3) Utilizar ciclos for anidados del tamano del arreglo el primero y del tamano del numero el segundo... Utilizando una verificacion if se controla que los caracteres de los arreglos se encuentren en codigo ascii entre el 30 y el 39 ***para pasarlo a entero***
       y en caso de no cumplir que se pase al siguiente elemento del arreglo. Hacer otra verificacion if donde en caso de que no exista dicha posicion, se mande automaticamente al archivo 0
    4) Dentro del if mandar a llamar a una funcion que verifique, mediante un switch, el valor del elemento que se esta analizando para ser enviado a uno de los archivos, tras primero  haber convertido ese arreglo a un String 
    5) Leer archivos en orden e ir colocando los elementos de cada archivo en el archivo original. 
    6) Volver a hacer todo, recursivo...
    */
    public String nombreArchivoOriginal;
    public int tipoOrdenamiento;
    public boolean verificaOrdenamiento;
    static int valorRecursivoMaximo=0;
    String numeros[];
    String bloque[];
    String bloqueAux[];
    
    ArrayList<Double> numerosDouble = new ArrayList<>();
    public ArrayList<String> numerosArchivoOriginalString = new ArrayList<>();
    public ArrayList<ArrayList<Integer>> numerosArchivoOriginalArregloEnteros = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    
    static String Q0 = "Q0.txt";
    static String Q1 = "Q1.txt";
    static String Q2 = "Q2.txt";
    static String Q3 = "Q3.txt";
    static String Q4 = "Q4.txt";
    static String Q5 = "Q5.txt";
    static String Q6 = "Q6.txt";
    static String Q7 = "Q7.txt";
    static String Q8 = "Q8.txt";
    static String Q9 = "Q9.txt";
    
    ArrayList<String> bloqueArchivoString = new ArrayList<>();
    
    Distribucion(String nombre, int tipoOrdenamiento){
        this.tipoOrdenamiento = tipoOrdenamiento;
        this.nombreArchivoOriginal = nombre;
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }
            }
            for(int i=0; i<numerosDouble.size(); i++){
                numerosArchivoOriginalString.add(numerosDouble.get(i).toString());
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    public void ArregloDeArreglos(){
        for(int t=0; t<numerosArchivoOriginalString.size(); t++){
            numerosArchivoOriginalArregloEnteros.add(new ArrayList<>());
            for(int q=0; q<numerosArchivoOriginalString.get(t).length(); q++){
                if(valorRecursivoMaximo<numerosArchivoOriginalString.get(t).length()){
                    valorRecursivoMaximo = numerosArchivoOriginalString.get(t).length();
                }
                numerosArchivoOriginalArregloEnteros.get(t).add(Integer.getInteger(numerosArchivoOriginalString.get(t))); //Se resta 48 por el código ASCII de [0-9] El "." es 46, por lo que valdría -2.
            }
        }
    }
                /*for(int j=0;j<numerosArchivoOriginalArregloEnteros.size();j++){
                    System.out.println(numerosArchivoOriginalString.get(j));
                    for(int k=0; k<numerosArchivoOriginalArregloEnteros.get(j).size();k++){
                        System.out.println(numerosArchivoOriginalArregloEnteros.get(j).get(k));
                        
                    }
                }
            }//Arreglo de arreglo de enteros
            /*int largoNumero = numerosArchivoOriginalString.get(t).length();
                //Si no tiene punto
            boolean punto = false;
            for(int q=0; q<numerosArchivoOriginalString.get(t).length(); q++){
                if(numerosArchivoOriginalArregloEnteros.get(t).get(q) == -2 ){
                    punto = true;
                }
            }
            if(punto = false){
                numerosArchivoOriginalArregloEnteros.get(t).add(-2);
                numerosArchivoOriginalArregloEnteros.get(t).add(0);
                numerosArchivoOriginalArregloEnteros.get(t).add(0);
            }
            else{    //Si cuenta por un punto, pero no está en la posición antepenúltima
                while(numerosArchivoOriginalArregloEnteros.get(t).get(largoNumero-1) != -2){ //Verificar donde debería ir un "." para dos decimales
                    numerosArchivoOriginalArregloEnteros.get(t).add(0);
                    largoNumero +=1;
                }
            }*/
    
    public ArrayList<String> lecturaArchivo(String archivo, String nombreArchivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split("/");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueAux = bloque[i].split(",");
                        for(int j=0; j<bloqueAux.length;j++){
                            bloqueArchivoString.add((bloqueAux[j]));
                        }
                        bloqueArchivoString.add("/");
                    }
                }  
                System.out.println("Bloque " + nombreArchivo);
                for(String d : bloqueArchivoString){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
    
    public void MetodoDistribucion(){
        //Aqui se crean los 10 archivos relacionados a cada cola
        crearArchivo(Q0, 0);
        crearArchivo(Q1, 1);
        crearArchivo(Q2, 2);
        crearArchivo(Q3, 3);
        crearArchivo(Q4, 4);
        crearArchivo(Q5, 5);
        crearArchivo(Q6, 6);
        crearArchivo(Q7, 7);
        crearArchivo(Q8, 8);
        crearArchivo(Q9, 9);
        
        //Proceso Distribución
        verificaOrdenamiento = false;
        while(verificaOrdenamiento == false){
            verificaOrdenamiento = true;
            
            
            // Arreglo de arreglos de los valores.

            
            //Llamar a Radix para que meta a los elementos en los archivos, tomando como argumento el tamaño más grande de los String? y de ahí ir pasando al primer elemento de cada arreglo.
            radixSort(0);
            
            
            
            //Sacar todos los datos de los archivos y volverlos a meter al ArrayList original, llamar de forma recursiva a esta función.
            
            

            //Verifica si el arreglo de Double original ya se encuentra ordenado.
            for(int pos=0; pos<numerosArchivoOriginalDouble.size() ;pos++){
                if(numerosArchivoOriginalDouble.get(pos) > numerosArchivoOriginalDouble.get(pos+1)){
                    verificaOrdenamiento = false;
                    break;
                }
            }          
        }
        System.out.println("El Archivo se encuentra ordenado");
    }
        
    public void radixSort(int posicionVerificando){
        int valor;
        try{
            
            FileReader lf0 = new FileReader("Q0.txt");
            FileReader lf1 = new FileReader("Q1.txt");
            FileReader lf2 = new FileReader("Q2.txt");
            FileReader lf3 = new FileReader("Q3.txt");
            FileReader lf4 = new FileReader("Q4.txt");
            FileReader lf5 = new FileReader("Q5.txt");
            FileReader lf6 = new FileReader("Q6.txt");
            FileReader lf7 = new FileReader("Q7.txt");
            FileReader lf8 = new FileReader("Q8.txt");
            FileReader lf9 = new FileReader("Q9.txt");
            
            BufferedReader blf0 = new BufferedReader(lf0);
            BufferedReader blf1 = new BufferedReader(lf1);
            BufferedReader blf2 = new BufferedReader(lf2);
            BufferedReader blf3 = new BufferedReader(lf3);
            BufferedReader blf4 = new BufferedReader(lf4);
            BufferedReader blf5 = new BufferedReader(lf5);
            BufferedReader blf6 = new BufferedReader(lf6);
            BufferedReader blf7 = new BufferedReader(lf7);
            BufferedReader blf8 = new BufferedReader(lf8);
            BufferedReader bf9 = new  BufferedReader(lf9);
            
            FileWriter f0 = new FileWriter("Q0.txt");
            FileWriter f1 = new FileWriter("Q1.txt");
            FileWriter f2 = new FileWriter("Q2.txt");
            FileWriter f3 = new FileWriter("Q3.txt");
            FileWriter f4 = new FileWriter("Q4.txt");
            FileWriter f5 = new FileWriter("Q5.txt");
            FileWriter f6 = new FileWriter("Q6.txt");
            FileWriter f7 = new FileWriter("Q7.txt");
            FileWriter f8 = new FileWriter("Q8.txt");
            FileWriter f9 = new FileWriter("Q9.txt");
            
            //Escribir los valores de los números en su respectivo archivo de acuerdo a la posición trabajada.
            for(int i=0; i<numerosArchivoOriginalArregloEnteros.size(); i++){
                if(numerosArchivoOriginalArregloEnteros.get(i).size() < posicionVerificando){ //En caso de que el número que se encuentre trabajando sea muy corto.
                    f0.write(numerosArchivoOriginalString.get(i));
                    f0.write(",");
                }
                else{
                    valor = numerosArchivoOriginalArregloEnteros.get(i).get(posicionVerificando);
                    switch(valor){
                            case 0:
                                f0.write(numerosArchivoOriginalString.get(i));
                                f0.write(",");
                                break;
                            case 1:
                                f1.write(numerosArchivoOriginalString.get(i));
                                f1.write(",");
                                break;
                            case 2:
                                f2.write(numerosArchivoOriginalString.get(i));
                                f2.write(",");
                                break;
                            case 3:
                                f3.write(numerosArchivoOriginalString.get(i));
                                f3.write(",");
                                break;
                            case 4:
                                f4.write(numerosArchivoOriginalString.get(i));
                                f4.write(",");
                                break;
                            case 5:
                                f5.write(numerosArchivoOriginalString.get(i));
                                f5.write(",");
                                break;
                            case 6:
                                f6.write(numerosArchivoOriginalString.get(i));
                                f6.write(",");
                                break;
                            case 7:
                                f7.write(numerosArchivoOriginalString.get(i));
                                f7.write(",");
                                break;
                            case 8:
                                f8.write(numerosArchivoOriginalString.get(i));
                                f8.write(",");
                                break;
                            case 9:
                                f9.write(numerosArchivoOriginalString.get(i));
                                f9.write(",");
                                break;     
                    }
                }
            }
            
            
            
            /*

            
                
                
                FileWriter f = new FileWriter(nombre,false);
            }*/
            f0.close();
            f1.close();
            f2.close();
            f3.close();
            f4.close();
            f5.close();
            f6.close();
            f7.close();
            f8.close();
            f9.close();
        for(int i=0; i<numerosArchivoOriginalDouble.size(); i++){
              double numero = numerosArchivoOriginalDouble.get(i);
              int digitosAntes = String.valueOf(numero).split("\\.")[0].length();
              int digitosDespues = String.valueOf(numero).split("\\.")[1].length();
              
              for(int j=digitosDespues-1;j>-1;j++){
                  
              }

          }  
        }catch(IOException e){
            System.out.println("ERROR DE ARCHIVO");
        }
    }
    
    public void ordenamiento(){
        ArregloDeArreglos();
        bloqueArchivoOriginalString = lecturaArchivo(nombreArchivoOriginal, "Original");
    }
    
    public void crearArchivo(String nombre, int cola){
        try {
            File file = new File(nombre);
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("ERROR AL CREAR EL ARCHIVO");
        }

    }
        
}