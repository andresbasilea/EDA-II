package ordenamientoexterno;
import java.util.*;
import java.io.*;

/**
 * Implementa el método de ordenamiento externo por <b>polifase</b>. El método de ordenamiento por polifase consiste
 * en aplicar una estrategia de generación de bloques mientras se realiza la lectura del archivo original. 
 * 
 * <p>
 * La fase 1 del ordenamiento consiste en la lectura y división del archivo original. En ella, se lee una cantidad <b>n</b>
 * de claves. Estas claves son ordenadas utilizando un algoritmo de ordenamiento interno (en este caso quicksort). Más tarde, 
 * se genera un bloque con esas claves y se coloca en el archivo auxiliar "AuxiliarPolifase1". Se repite el proceso y se colocan
 * las <b>n</b> claves en el archivo auxiliar "AuxiliarPolifase2" para, más tarde, generar bloques y guardarlos de manera intercalada entre
 * ambos archivos auxiliares. 
 * </p>
 * 
 * <p>
 * En la fase 2 del ordenamiento, se intercala el primer bloque del archivo auxiliar "AuxiliarPolifase1" con el primer bloque del archivo
 * auxiliar "AuxiliarPolifase2" y se deja el resultado en el archivo original. Luego, se intercala el siguiente bloque de cada archivo y se
 * coloca el resultado en un tercer archivo auxiliar "AuxiliarPolifase3". Se repiten dichos pasos hasta que ya no haya más claves por procesar.
 * </p>
 * 
 * 
 * @author Basile Álvarez Andrés, Keller Ascencio Rodolfo, Martínez Jiménez María Fernanda
 */
public class Polifase {

    String archivoOriginal;
    int tipoOrdenamiento;
    int claves;
    String numeros[];
    String bloque[];
    String bloqueAux[];
    
    Quicksort sort = new Quicksort();
    boolean bloquesNoCompletos = false;
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<Double> numerosDouble1 = new ArrayList<>();
    ArrayList<Double> numerosDouble2 = new ArrayList<>();
    ArrayList<String> bloqueArchivo1String = new ArrayList<>();
    ArrayList<String> bloqueArchivo2String = new ArrayList<>();
    ArrayList<String> bloqueArchivo3String = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    
    static String nomAux1 = "AuxiliarPolifase1.txt";
    static String nomAux2 = "AuxiliarPolifase2.txt";
    static String nomAux3 = "AuxiliarPolifase3.txt";
    
    /**
     * El constructor de la clase recibe como parámetros el nombre del archivo a ordenarse (con su respectiva extensión),
     * el tipo de ordenamiento (1 indica ascendente y 2, descendente) y el tamaño "n" de claves que se leerán por cada bloque de polifase.
     * Dentro del constructor, se lee el archivo original y se guardan todos sus elementos en el arreglo de cadenas "numeros". 
     * @param nombre el nombre del archivo a ordenar.
     * @param tipoOrdenamiento el tipo de ordenamiento  (1=ascendente, 2=descendente).
     * @param claves el número de claves por bloque.
     */
    Polifase(String nombre, int tipoOrdenamiento, int claves){
        this.tipoOrdenamiento = tipoOrdenamiento;
        this.archivoOriginal = nombre;
        this.claves = claves;
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    /**
     * En este método de tipo <b>void</b>, se realiza la primera fase de ordenamiento ascendente. En ella, se utiliza 
     * el ArrayList con los números a ordenar y, mediante quicksort, se ordenan los elementos.  Los elementos ordenados
     * son los correspondientes a "numerosDouble1" y "numerosDouble2". Una vez realizado el ordenamiento, se escribe en 
     * los archivos auxiliares a cada uno de los bloques generados. Finalmente, se vacía el archivo original para poderlo 
     * utilizar en la siguiente fase del ordenamiento. 
     */
    public void fase1BloquesAscendente(){
        try{
            FileWriter archOriginal = new FileWriter(archivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int termina = 1;
            while(claves<numerosDouble.size()){
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble1.add(numerosDouble.remove(0).doubleValue());
                            termina=1;
                        }
                    }
                    sort.sortAscendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    while(!numerosDouble1.isEmpty()){                            
                        aux1.write(numerosDouble1.remove(0).toString());
                        if(!numerosDouble1.isEmpty()){
                            aux1.write(",");
                        }
                    }
                    aux1.write("/");
                }
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble2.add(numerosDouble.remove(0).doubleValue());
                            termina=2;
                        }
                    }
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    while(!numerosDouble2.isEmpty()){                            
                        aux2.write(numerosDouble2.remove(0).toString());
                        if(!numerosDouble2.isEmpty()){
                            aux2.write(",");
                        }
                    }
                    aux2.write("/");
                }
            }
            while(!numerosDouble.isEmpty()){
                if(termina == 1){
                    numerosDouble2.add(numerosDouble.remove(0).doubleValue());
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux2.write(numerosDouble2.remove(0).toString());
                    if(!numerosDouble.isEmpty()){
                        aux2.write(",");
                    }
                }
                if(termina == 2){
                    numerosDouble1.add(numerosDouble.remove(0).doubleValue());
                }
                bloquesNoCompletos=true;
            }
            if(termina == 1 && bloquesNoCompletos==true){
                while(!numerosDouble2.isEmpty()){
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux1.write(numerosDouble2.remove(0).toString());
                    if(!numerosDouble2.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux2.write("/");                 
            }
            if(termina == 2 && bloquesNoCompletos==true){
                while(!numerosDouble1.isEmpty()){
                    sort.sortAscendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    aux1.write(numerosDouble1.remove(0).toString());
                    if(!numerosDouble1.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux1.write("/");                  
            }
            aux1.close();
            aux2.close();
            archOriginal.write("");
            archOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    /**
     * Este método de tipo <b>void</b> realiza la primera fase de ordenamiento descendente. En ella, se utiliza un ArrayList
     * con los números a ordenar y, mediante quicksort, se ordenan los elementos (descendente). Los elementos ordenados son los 
     * correspondientes a "numerosDouble1" y "numerosDouble2". Una vez realizado el ordenamiento, se escribe en los archivos auxiliares
     * a cada uno de los bloques generados. Finalmente, se vacía el archivo original para poderlo utilizar en la siguiente fase del ordenamiento. 
     */
    public void fase1BloquesDescendente(){
        Quicksort sort = new Quicksort();
        try{
            FileWriter archOriginal = new FileWriter(archivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int termina = 1;
            while(claves<numerosDouble.size()){
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble1.add(numerosDouble.remove(0).doubleValue());
                            termina=1;
                        }
                    }
                    sort.sortDescendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    while(!numerosDouble1.isEmpty()){                            
                        aux1.write(numerosDouble1.remove(0).toString());
                        if(!numerosDouble1.isEmpty()){
                            aux1.write(",");
                        }
                    }
                    aux1.write("/");
                }
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble2.add(numerosDouble.remove(0).doubleValue());
                            termina=2;
                        }
                    }
                    sort.sortDescendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    while(!numerosDouble2.isEmpty()){                            
                        aux2.write(numerosDouble2.remove(0).toString());
                        if(!numerosDouble2.isEmpty()){
                            aux2.write(",");
                        }
                    }
                    aux2.write("/");
                }
            }
            while(!numerosDouble.isEmpty()){
                if(termina == 1){
                    numerosDouble2.add(numerosDouble.remove(0).doubleValue());
                    sort.sortDescendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux2.write(numerosDouble2.remove(0).toString());
                    if(!numerosDouble.isEmpty()){
                        aux2.write(",");
                    }
                }
                if(termina == 2){
                    numerosDouble1.add(numerosDouble.remove(0).doubleValue());
                }
                bloquesNoCompletos=true;
            }
            if(termina == 1 && bloquesNoCompletos==true){
                while(!numerosDouble2.isEmpty()){
                    sort.sortDescendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux1.write(numerosDouble2.remove(0).toString());
                    if(!numerosDouble2.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux2.write("/");                 
            }
            if(termina == 2 && bloquesNoCompletos==true){
                while(!numerosDouble1.isEmpty()){
                    sort.sortDescendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    aux1.write(numerosDouble1.remove(0).toString());
                    if(!numerosDouble1.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux1.write("/");                  
            }
            aux1.close();
            aux2.close();
            archOriginal.write("");
            archOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
     
    /**
     * Este método permite leer un archivo y guardar los elementos dividios por "/" en el arreglo de 
     * cadenas "bloque" para después ser agregados al ArrayList "bloqueArchivoString" y finalizar con un "/" que indica el fin
     * del bloque agregado al ArrayList.
     * @param archivo el nombre del archcivo a leer.
     * @return se regresa el <b>bloqueArchivoString</b>, ArrayList que contiene los elementos leídos del archivo.
     */
    public ArrayList<String> lecturaArchivo(String archivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split("/");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueAux = bloque[i].split(",");
                        for(int j=0; j<bloqueAux.length;j++){
                            bloqueArchivoString.add((bloqueAux[j]));
                        }
                        bloqueArchivoString.add("/");
                    }
                }  
            }
            laux.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
    
    /**
     * Método de tipo <b>void</b> que permite imprimir los elementos ubicados en un ArrayList.
     * @param nombreArchivo el nombre del archivo de donde proviene el bloque (puede ser cualquier cadena).
     * @param bloqueArchivoString el nombre del ArrayList de donde se leerán los elementos. 
     */
    public void impresionBloques(String nombreArchivo, ArrayList<String> bloqueArchivoString){
        System.out.println("Bloque " + nombreArchivo);
        for(String d : bloqueArchivoString){
            System.out.println(d);
        }
        System.out.println();
    }
    
    /**
     * Este método de tipo <b>void</b> permite leer los bloques obtenidos a partir de los archivos auxiliares 1 y 2 y 
     * escribir la unión de los bloques en el archivo original y en el tercer archivo auxiliar según corresponda. 
     * Dentro del método, se utiliza quicksort para que los bloques escritos (obtenidos a partir de los archivos auxiliares) se encuentren ordenados
     * al pasarlos al archivo original y al tercer auxiliar. 
     * Cada vez que se termina de escribir la unión de dos bloques en el archivo original o auxiliar 3, se escribe el símbolo "/" para indicar el final del bloque.
     * EL ORDENAMIENTO REALIZADO PARA UNIR LOS BLOQUES Y COLOCARLOS EN EL ARCHIVO ORIGINAL O TERCER AUXILIAR ORDENA LOS ELEMENTOS DE MANERA ASCENDETE.
     */
    public void escrituraBloquesArchivoOriginalyTercerArchivoAscendente(){
        try{
            FileWriter archivoOriginal1 = new FileWriter(archivoOriginal,false);
            FileWriter archivoAux3 = new FileWriter(nomAux3,false);
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo2String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){    
                    while(bloqueArchivo1String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo1String.remove(0)));
                    }
                    bloqueArchivo1String.remove(0);
                }
                if(!bloqueArchivo2String.isEmpty()){ 
                    while(bloqueArchivo2String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo2String.remove(0)));
                    }
                    bloqueArchivo2String.remove(0);
                }
                    sort.sortAscendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoOriginal1.write(numerosDouble.remove(0).toString());
                        archivoOriginal1.write(",");
                    }
                    archivoOriginal1.write("/");
                if(!bloqueArchivo1String.isEmpty()){ 
                    if(!bloqueArchivo1String.isEmpty()){
                        while(bloqueArchivo1String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo1String.remove(0)));
                        }
                        bloqueArchivo1String.remove(0);
                    }
                }
                if(!bloqueArchivo2String.isEmpty()){ 
                    if(!bloqueArchivo2String.isEmpty()){
                        while(bloqueArchivo2String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo2String.remove(0)));
                        }
                        bloqueArchivo2String.remove(0);
                    }
                }
                    sort.sortAscendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux3.write(numerosDouble.remove(0).toString());
                        archivoAux3.write(",");
                    }
                    archivoAux3.write("/");
            }
            archivoOriginal1.close();
            archivoAux3.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * Este método de tipo <b>void</b> permite leer los bloques obtenidos a partir de los archivos auxiliares 1 y 2 y 
     * escribir la unión de los bloques en el archivo original y en el tercer archivo auxiliar según corresponda. 
     * Dentro del método, se utiliza quicksort para que los bloques escritos (obtenidos a partir de los archivos auxiliares) se encuentren ordenados
     * al pasarlos al archivo original y al tercer auxiliar. 
     * Cada vez que se termina de escribir la unión de dos bloques en el archivo original o auxiliar 3, se escribe el símbolo "/" para indicar el final del bloque.
     * EL ORDENAMIENTO REALIZADO PARA UNIR LOS BLOQUES Y COLOCARLOS EN EL ARCHIVO ORIGINAL O TERCER AUXILIAR ORDENA LOS ELEMENTOS DE MANERA DESCENDENTE.
     */
    public void escrituraBloquesArchivoOriginalyTercerArchivoDescendente(){
        try{
            FileWriter archivoOriginal1 = new FileWriter(archivoOriginal,false);
            FileWriter archivoAux3 = new FileWriter(nomAux3,false);
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo2String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){    
                    while(bloqueArchivo1String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo1String.remove(0)));
                    }
                    bloqueArchivo1String.remove(0);
                }
                if(!bloqueArchivo2String.isEmpty()){ 
                    while(bloqueArchivo2String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo2String.remove(0)));
                    }
                    bloqueArchivo2String.remove(0);
                }
                    sort.sortDescendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoOriginal1.write(numerosDouble.remove(0).toString());
                        archivoOriginal1.write(",");
                    }
                    archivoOriginal1.write("/");
                if(!bloqueArchivo1String.isEmpty()){ 
                    if(!bloqueArchivo1String.isEmpty()){
                        while(bloqueArchivo1String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo1String.remove(0)));
                        }
                        bloqueArchivo1String.remove(0);
                    }
                }
                if(!bloqueArchivo2String.isEmpty()){ 
                    if(!bloqueArchivo2String.isEmpty()){
                        while(bloqueArchivo2String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo2String.remove(0)));
                        }
                        bloqueArchivo2String.remove(0);
                    }
                }
                    sort.sortDescendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux3.write(numerosDouble.remove(0).toString());
                        archivoAux3.write(",");
                    }
                    archivoAux3.write("/");
            }
            archivoOriginal1.close();
            archivoAux3.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * Este método de tipo <b>void</b> permite leer los bloques obtenidos a partir del archivo original y el auxiliar 3 y 
     * escribir la unión de los bloques en el archivo auxiliar 1 y 2 según corresponda. 
     * Dentro del método, se utiliza quicksort para que los bloques escritos (obtenidos a partir del archivo original y tercer auxiliar) se encuentren ordenados
     * al pasarlos a los primeros dos archivos auxiliares. 
     * Cada vez que se termina de escribir la unión de dos bloques en los primeros auxiliares, se escribe el símbolo "/" para indicar el final del bloque.
     * EL ORDENAMIENTO REALIZADO PARA UNIR LOS BLOQUES Y COLOCARLOS EN EL ARCHIVO AUXILIAR 1 Y 2 ORDENA LOS ELEMENTOS DE MANERA ASCENDETE.
     */
    public void escrituraBloquesAuxiliaresAscendente(){
        try{
            FileWriter archivoAux1 = new FileWriter(nomAux1,false);
            FileWriter archivoAux2 = new FileWriter(nomAux2,false);
            while(!bloqueArchivoOriginalString.isEmpty()||!bloqueArchivo3String.isEmpty()){
                if(!bloqueArchivoOriginalString.isEmpty()){    
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivoOriginalString.remove(0)));
                    }
                    bloqueArchivoOriginalString.remove(0);
                }
                if(!bloqueArchivo3String.isEmpty()){ 
                    while(bloqueArchivo3String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo3String.remove(0)));
                    }
                    bloqueArchivo3String.remove(0);
                }
                    sort.sortAscendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux1.write(numerosDouble.remove(0).toString());
                        archivoAux1.write(",");
                    }
                    archivoAux1.write("/");
                if(!bloqueArchivoOriginalString.isEmpty()){ 
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        while(bloqueArchivoOriginalString.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivoOriginalString.remove(0)));
                        }
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
                if(!bloqueArchivo3String.isEmpty()){ 
                    if(!bloqueArchivo3String.isEmpty()){
                        while(bloqueArchivo3String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo3String.remove(0)));
                        }
                        bloqueArchivo3String.remove(0);
                    }
                }
                    sort.sortAscendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux2.write(numerosDouble.remove(0).toString());
                        archivoAux2.write(",");
                    }
                    archivoAux2.write("/");
            }
            archivoAux1.close();
            archivoAux2.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * Este método de tipo <b>void</b> permite leer los bloques obtenidos a partir del archivo original y el auxiliar 3 y 
     * escribir la unión de los bloques en el archivo auxiliar 1 y 2 según corresponda. 
     * Dentro del método, se utiliza quicksort para que los bloques escritos (obtenidos a partir del archivo original y tercer auxiliar) se encuentren ordenados
     * al pasarlos a los primeros dos archivos auxiliares. 
     * Cada vez que se termina de escribir la unión de dos bloques en los primeros auxiliares, se escribe el símbolo "/" para indicar el final del bloque.
     * EL ORDENAMIENTO REALIZADO PARA UNIR LOS BLOQUES Y COLOCARLOS EN EL ARCHIVO AUXILIAR 1 Y 2 ORDENA LOS ELEMENTOS DE MANERA DESCENDENTE.
     */
    public void escrituraBloquesAuxiliaresDescendente(){
        try{
            FileWriter archivoAux1 = new FileWriter(nomAux1,false);
            FileWriter archivoAux2 = new FileWriter(nomAux2,false);
            while(!bloqueArchivoOriginalString.isEmpty()||!bloqueArchivo3String.isEmpty()){
                if(!bloqueArchivoOriginalString.isEmpty()){    
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivoOriginalString.remove(0)));
                    }
                    bloqueArchivoOriginalString.remove(0);
                }
                if(!bloqueArchivo3String.isEmpty()){ 
                    while(bloqueArchivo3String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo3String.remove(0)));
                    }
                    bloqueArchivo3String.remove(0);
                }
                    sort.sortDescendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux1.write(numerosDouble.remove(0).toString());
                        archivoAux1.write(",");
                    }
                    archivoAux1.write("/");
                if(!bloqueArchivoOriginalString.isEmpty()){ 
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        while(bloqueArchivoOriginalString.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivoOriginalString.remove(0)));
                        }
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
                if(!bloqueArchivo3String.isEmpty()){ 
                    if(!bloqueArchivo3String.isEmpty()){
                        while(bloqueArchivo3String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo3String.remove(0)));
                        }
                        bloqueArchivo3String.remove(0);
                    }
                }
                    sort.sortDescendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux2.write(numerosDouble.remove(0).toString());
                        archivoAux2.write(",");
                    }
                    archivoAux2.write("/");
            }
            archivoAux1.close();
            archivoAux2.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * Este método de tipo <b>void</b> permite leer los archivos auxiliares e imprimir los bloques generados. 
     * Además, junta los bloques generados en el archivo original y tercer archivo auxiliar dentro de un ciclo 
     *  <b>do-while</b> que termina cuando la verificación del ordenamiento sea igual a  <b>true</b>. 
     * Este método funciona para ORDENAMIENTO ASCENDENTE.
     */
    public void fase2OrdenamientoAscendente(){
        do{
            bloqueArchivo1String = lecturaArchivo(nomAux1);
            impresionBloques("1",bloqueArchivo1String);
            bloqueArchivo2String = lecturaArchivo(nomAux2);
            impresionBloques("2",bloqueArchivo2String);
            escrituraBloquesArchivoOriginalyTercerArchivoAscendente();
            bloqueArchivo3String = lecturaArchivo(nomAux3);
            if(!bloqueArchivo3String.isEmpty()){
                bloqueArchivo3String.clear();
                bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
                impresionBloques("Original",bloqueArchivoOriginalString);
                bloqueArchivo3String = lecturaArchivo(nomAux3);
                impresionBloques("3",bloqueArchivo3String);
                escrituraBloquesAuxiliaresAscendente();
            }
        }while(verificaOrdenamiento()==false);
    }
    
    /**
     * Este método de tipo <b>void</b> permite leer los archivos auxiliares e imprimir los bloques generados. 
     * Además, junta los bloques generados en el archivo original y tercer archivo auxiliar dentro de un ciclo 
     * <b>do-while</b> que termina cuando la verificación del ordenamiento sea igual a  <b>true</b>. 
     * Este método funciona para ORDENAMIENTO DESCENDENTE.
     */
    public void fase2OrdenamientoDescendente(){
        do{
            bloqueArchivo1String = lecturaArchivo(nomAux1);
            impresionBloques("1",bloqueArchivo1String);
            bloqueArchivo2String = lecturaArchivo(nomAux2);
            impresionBloques("2",bloqueArchivo2String);
            escrituraBloquesArchivoOriginalyTercerArchivoDescendente();
            bloqueArchivo3String = lecturaArchivo(nomAux3);
            if(!bloqueArchivo3String.isEmpty()){
                bloqueArchivo3String.clear();
                bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
                impresionBloques("Original",bloqueArchivoOriginalString);
                bloqueArchivo3String = lecturaArchivo(nomAux3);
                impresionBloques("3",bloqueArchivo3String);
                escrituraBloquesAuxiliaresDescendente();
            }
        }while(verificaOrdenamiento()==false);
    }
    
    /**
     * Este método de tipo <b>boolean</b> devuelve <b>true</b> en caso de que el ordenamiento se haya completado 
     * y <b>false</b> en caso contrario.Esto se logra mediante la lectura del archivo original y del archivo auxiliar
     * número 3. Si se cumple que el archivo original únicamente cuenta con 1 símnbolo "/" y que el archivo auxiliar 3
     *´no cuenta con ningún "/", se puede afirmar que el archivo original se encuentra ordenado. 
     * @return regresa <b>true</b> en caso de que el archivo se encuentre ordenado o <b>false</b> en caso contrario. 
     */
    public boolean verificaOrdenamiento(){
        bloqueArchivo3String = lecturaArchivo(nomAux3);
        bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
        boolean verificaOrdenamiento = true;
        int contadLasLineas = 0;
        int contadLasLineas3 = 0;
        for(int m=0; m<bloqueArchivoOriginalString.size(); m++){
            if(bloqueArchivoOriginalString.get(m)=="/"){  
                contadLasLineas++;
            }
        } 
        for(int m=0; m<bloqueArchivo3String.size(); m++){
            if(bloqueArchivo3String.get(m)=="/"){  
                contadLasLineas3++;
            }
        } 
        if((contadLasLineas==1||contadLasLineas==0)&&(contadLasLineas3==0)){
            verificaOrdenamiento = true;
        }
        else{
            verificaOrdenamiento=false;
        }
        bloqueArchivoOriginalString.clear();
        bloqueArchivo3String.clear();
        System.out.println(verificaOrdenamiento);
        return verificaOrdenamiento;
    }
    
    /**
     * En este método de tipo <b>void</b>, se realizan las funciones necesarias para ordenar un archivo con números reales de manera ascendente o 
     * descendente. Primero se verifica el tipo de ordenamiento deseado para después llamar a los métodos necesarios. 
     * Al llamar a este método, se logra ordenar el archivo con números en el orden deseado por el usuario. 
     */
    public void ordenamiento(){
        if(tipoOrdenamiento==1){
            fase1BloquesAscendente();
            fase2OrdenamientoAscendente();
            bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
            impresionBloques("Original",bloqueArchivoOriginalString);
        }
        
        if(tipoOrdenamiento == 2){
            fase1BloquesDescendente();
            fase2OrdenamientoDescendente();
            bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
            impresionBloques("Original",bloqueArchivoOriginalString);
        }
    }
    
}
