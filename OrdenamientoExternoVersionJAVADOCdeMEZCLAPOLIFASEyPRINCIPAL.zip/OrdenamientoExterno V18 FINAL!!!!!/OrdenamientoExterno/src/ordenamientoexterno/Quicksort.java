package ordenamientoexterno;
import java.util.*;

public class Quicksort {
    int partitionAscendente(ArrayList<Double> arr, int low, int high){
        int pivot = high;
        int j,i=low-1;
        for(j=low;j<high; j++){
            if(arr.get(j)<= arr.get(pivot)){
                i++;
                double temp = arr.get(i);
    	        arr.set(i,arr.get(j));
    	        arr.set(j,temp);
            }
        }
        double temp = arr.get(i+1);
        arr.set(i+1,arr.get(high));
        arr.set(high,temp);
        return i+1;
    }

    void sortAscendente(ArrayList<Double> arr, int low, int high){
        if(low<high){
            int pi = partitionAscendente(arr, low, high);
            sortAscendente(arr,low,pi-1);
            sortAscendente(arr,pi+1,high);
        }
    }
    
    int partitionDescendente(ArrayList<Double> arr, int low, int high){
        int pivot = high;
        int j,i=low-1;
        for(j=low;j<high; j++){
            if(arr.get(j)>= arr.get(pivot)){
                i++;
                double temp = arr.get(i);
    	        arr.set(i,arr.get(j));
    	        arr.set(j,temp);
            }
        }
        double temp = arr.get(i+1);
        arr.set(i+1,arr.get(high));
        arr.set(high,temp);
        return i+1;
    }

    void sortDescendente(ArrayList<Double> arr, int low, int high){
        if(low<high){
            int pi = partitionDescendente(arr, low, high);
            sortDescendente(arr,low,pi-1);
            sortDescendente(arr,pi+1,high);
        }
    }
}
