/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamientoexterno;
import java.util.*;
import java.io.*;
/**
 *
 * @author AndresBasile
 */
public class Polifase {
    /*
        1) crear dos archivos adicionales
        2) atributo final de n claves...
        2.1) pasar elementos a double
        3) leer el original y pasarlo a un array list (ordenarlo con BUBBLE SORT (PRACTICA 7)).
        4) Ciclo while con variable contadora que va a empezar en 0 y verifica que sea menor a "n" (variable final) y que el arraylist sea != empty.
            Dentro del ciclo while convertir cada elemento del arraylist a String y enviarlo a un archivo... (tendria que haber dos ciclos while adentro para mandar a los archivos (1 y 2) y un while afuera
            para verificar que este ordenado 
            Tienes el archivo original arraylist, envias bloques al archivo 1 y 2 y verificas en todo momento que el arraylist tenga elementos (3 ciclos while, dos dentro de uno) el de fuera verifica que el
            arraylist no este vacio. El primer while verifica que no este vacio y una variable contadora que va de 0 a n y cuenta los elementos que se estan enviando, cuando la variable contadora sea igual a n 
            va a pasar al siguiente while. 
            
            OBSERVACION -> CADA QUE SE TERMINA UNO DE LOS CICLOS WHILE DE ADENTRO SE DEBE ESCRIBIR UN MARCADOR EN EL ARCHIVO PARA SEPARAR LOS BLOQUES ENVIADOS.
            
        5) Crear cuatro variables contadoras para los bloques,una para cada archivo (2) que evalue el bloque que nos encontramos leyendo y otra para cada archivo (2) que evalue el numero total de bloques dentro de este archivo.
    
    
    */
    
    String nombre;
    int particiones;
    int tipoOrdenamiento;
    int claves;
    String numeros[];
    String bloque1[];
    String bloque2[];
    String bloque1Aux[];
    String bloque2Aux[];
    String bloque1Original[];
    String bloque1OriginalAux[];
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<Double> numerosDouble1 = new ArrayList<>();
    ArrayList<Double> numerosDouble2 = new ArrayList<>();
    ArrayList<String> bloqueArchivo1String = new ArrayList<>();
    ArrayList<String> bloqueArchivo2String = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    ArrayList<Double> bloqueArchivoOriginalDouble = new ArrayList<>();
    static String nomAux1 = "AuxiliarPolifase1.txt";
    static String nomAux2 = "AuxiliarPolifase2.txt";
    static String nomAux3 = "AuxiliarPolifase3.txt";
    boolean bloquesNoCompletos = false;
    
    Polifase(String nombre, int tipoOrdenamiento, int claves){
        this.tipoOrdenamiento = tipoOrdenamiento;
        this.nombre = nombre;
        this.claves = claves;
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    public void fase1Bloques(){
        Quicksort sort = new Quicksort();
        try{
            FileWriter archivoOriginal = new FileWriter(nombre,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int contador = 0;
            int termina = 1;
            while(claves<numerosDouble.size()){
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble1.add(numerosDouble.remove(contador).doubleValue());
                            termina=1;
                        }
                    }
                    sort.sortAscendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    while(!numerosDouble1.isEmpty()){                            
                        aux1.write(numerosDouble1.remove(contador).toString());
                        if(!numerosDouble1.isEmpty()){
                            aux1.write(",");
                        }
                    }
                    aux1.write("/");
                }
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble2.add(numerosDouble.remove(contador).doubleValue());
                            termina=2;
                        }
                    }
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    while(!numerosDouble2.isEmpty()){                            
                        aux2.write(numerosDouble2.remove(contador).toString());
                        if(!numerosDouble2.isEmpty()){
                            aux2.write(",");
                        }
                    }
                    aux2.write("/");
                }
            }
            while(!numerosDouble.isEmpty()){
                if(termina == 1){
                    numerosDouble2.add(numerosDouble.remove(contador).doubleValue());
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux2.write(numerosDouble2.remove(contador).toString());
                    if(!numerosDouble.isEmpty()){
                        aux2.write(",");
                    }
                }
                if(termina == 2){
                    numerosDouble1.add(numerosDouble.remove(contador).doubleValue());
                }
                bloquesNoCompletos=true;
            }
            if(termina == 1 && bloquesNoCompletos==true){
                while(!numerosDouble2.isEmpty()){
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux1.write(numerosDouble2.remove(contador).toString());
                    if(!numerosDouble2.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux2.write("/");                 
            }
            if(termina == 2 && bloquesNoCompletos==true){
                while(!numerosDouble1.isEmpty()){
                    sort.sortAscendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    aux1.write(numerosDouble1.remove(contador).toString());
                    if(!numerosDouble1.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux1.write("/");                  
            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    public void lecturaArchivoAuxiliar1(){
        try{
            FileReader laux1 = new FileReader(nomAux1); 
            BufferedReader blaux1 = new BufferedReader(laux1);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque1 = numero.split("/");
                for(int i = 0;i<bloque1.length;i++){
                    if(bloque1[i]!=null){
                        bloque1Aux = bloque1[i].split(",");
                        for(int j=0; j<bloque1Aux.length;j++){
                            bloqueArchivo1String.add((bloque1Aux[j]));
                        }
                        bloqueArchivo1String.add("/");
                    }
                }  
                System.out.println("Bloque1");
                for(String d : bloqueArchivo1String){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void lecturaArchivoAuxiliar2(){
        try{
            FileReader laux2 = new FileReader(nomAux2);
            BufferedReader blaux2 = new BufferedReader(laux2);
            while(true){
                String numero = blaux2.readLine();
                if(numero == null)
                    break;
                bloque2 = numero.split("/");
                for(int i = 0;i<bloque2.length;i++){
                    if(bloque2[i]!=null){
                        bloque2Aux = bloque2[i].split(",");
                        for(int j=0; j<bloque2Aux.length;j++){
                            bloqueArchivo2String.add((bloque2Aux[j]));
                        }
                        bloqueArchivo2String.add("/");
                    }
                }  
                System.out.println("Bloque2");
                for(String d : bloqueArchivo2String){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux2.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void escrituraBloquesArchivoOriginal(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombre,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))<Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                } //bien
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo1String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void leerArchivoOriginalPasarAAuxiliares(){

        try{
            FileReader archivoOriginal = new FileReader(nombre);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);
            FileWriter aux1 = new FileWriter(nomAux1,false);
            FileWriter aux2 = new FileWriter(nomAux2,false);
            
            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
                
                System.out.println("BloqueOriginal");
                for(String d : bloqueArchivoOriginalString){
                    System.out.println(d);
                }
                System.out.println();
                
                while(!bloqueArchivoOriginalString.isEmpty()){
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        aux1.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux1.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux1.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)!="/"){
                        aux2.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux2.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux2.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
            }
            bArchivoOriginal.close();
            aux1.close();
            aux2.close();
        }catch(IOException e){
            System.out.println("ERROR¿?");
        } 

    }
    
    public void fase2Ordenamiento(){
        do{
            lecturaArchivoAuxiliar1();
            lecturaArchivoAuxiliar2();
            escrituraBloquesArchivoOriginal();
            leerArchivoOriginalPasarAAuxiliares();
        }while(verificaOrdenamiento()==false);
    }
    
    public void lecturaArchivoOriginal(){
        try{
            FileReader archivoOriginal = new FileReader(nombre);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);

            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
            }
            bArchivoOriginal.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public boolean verificaOrdenamiento(){
        lecturaArchivoOriginal();
        boolean verificaOrdenamiento = true;
        int contadLasLineas = 0;
        for(int m=0; m<bloqueArchivoOriginalString.size(); m++){
            if(bloqueArchivoOriginalString.get(m)=="/"){  
                contadLasLineas++;
            }
        } 
        if(contadLasLineas==1||contadLasLineas==0){
            verificaOrdenamiento = true;
        }
        else{
            verificaOrdenamiento=false;
        }
        bloqueArchivoOriginalString.clear();
        return verificaOrdenamiento;
    }
    
    public void ordenamiento(){
        if(tipoOrdenamiento==1){
            fase1Bloques();
            fase2Ordenamiento();          
        }
        
        if(tipoOrdenamiento == 2){
            fase1Bloques();
            //fase2Ordenamiento();
        }
    }
    
}
