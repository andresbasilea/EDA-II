package ordenamientoexterno;
import java.util.*;
import java.io.*;

public class Distribucion {
    public String nombreArchivoOriginal;
    public int tipoOrdenamiento;
    public boolean verificaOrdenamiento;
    static int valorRecursivoMaximo=0;
    String bloque[];
    String bloqueAux[];
    
    ArrayList<Double> numerosDouble = new ArrayList<>();
    public LinkedList<String> numerosArchivoOriginalString = new LinkedList<>();
    public ArrayList<ArrayList<Double>> numerosArchivoOriginalArregloDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    
    ArrayList<String> Cola0 = new ArrayList<>();
    ArrayList<String> Cola1 = new ArrayList<>();
    ArrayList<String> Cola2 = new ArrayList<>();
    ArrayList<String> Cola3 = new ArrayList<>();
    ArrayList<String> Cola4 = new ArrayList<>();
    ArrayList<String> Cola5 = new ArrayList<>();
    ArrayList<String> Cola6 = new ArrayList<>();
    ArrayList<String> Cola7 = new ArrayList<>();
    ArrayList<String> Cola8 = new ArrayList<>();
    ArrayList<String> Cola9 = new ArrayList<>();
    
    static String Q0 = "Q0.txt";
    static String Q1 = "Q1.txt";
    static String Q2 = "Q2.txt";
    static String Q3 = "Q3.txt";
    static String Q4 = "Q4.txt";
    static String Q5 = "Q5.txt";
    static String Q6 = "Q6.txt";
    static String Q7 = "Q7.txt";
    static String Q8 = "Q8.txt";
    static String Q9 = "Q9.txt";
    
    ArrayList<String> bloqueArchivoString = new ArrayList<>();
    
    Distribucion(String nombre, int tipoOrdenamiento){
        this.tipoOrdenamiento = tipoOrdenamiento;
        this.nombreArchivoOriginal = nombre;
    }
    
    public void lecturaOriginal(){
        String numeros[];
        numerosDouble.clear();
        numerosArchivoOriginalString.clear();
        try{
            FileReader lArchivo = new FileReader(nombreArchivoOriginal);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }
            }
            for(int i=0; i<numerosDouble.size(); i++){
                numerosArchivoOriginalString.add(numerosDouble.get(i).toString());
            }
            FileWriter original = new FileWriter(nombreArchivoOriginal,false);
            original.write("");
            original.close();
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    public void ValorRecursivoMaximo(){
        for(int t=0; t<numerosArchivoOriginalString.size(); t++){
            for(int q=0; q<numerosArchivoOriginalString.get(t).length(); q++){
                if(valorRecursivoMaximo<numerosArchivoOriginalString.get(t).length()){
                valorRecursivoMaximo = numerosArchivoOriginalString.get(t).length()+2;
                    System.out.println("Valor Recursivo Máximo " + valorRecursivoMaximo);
                }
            }
        }
    }
    
    public void ArregloDeArreglos(){
        String temporal;
        String temporalDeTemporada;
        numerosArchivoOriginalArregloDouble.clear();
        for(int t=0; t<numerosArchivoOriginalString.size(); t++){
            numerosArchivoOriginalArregloDouble.add(new ArrayList<>());
            temporal = numerosArchivoOriginalString.get(t);
            System.out.println("Temporal " + temporal);
            numerosArchivoOriginalArregloDouble.get(t).add(Double.parseDouble(temporal));
            //System.out.println("numArchOriStr " +numerosArchivoOriginalString.get(t));
            temporal = numerosArchivoOriginalArregloDouble.get(t).toString();
            for(int k=1; k<temporal.length()-1;k++){
                numerosArchivoOriginalArregloDouble.get(t).add(new Double(0));
                System.out.println("Arreglo Enteros "+numerosArchivoOriginalArregloDouble.get(t));
                //System.out.println("Temporal " + temporal);
                if(temporal.charAt(k) != 46){
                    temporalDeTemporada = String.valueOf(temporal.charAt(k));
                    numerosArchivoOriginalArregloDouble.get(t).set(k,Double.parseDouble(temporalDeTemporada));
                    //System.out.println("TemporalDeTemporada "+temporalDeTemporada);
                }
                if((temporal.charAt(k) == 46) && temporal.toString().length()==k+3){
                    numerosArchivoOriginalArregloDouble.get(t).add(0.0);
                    //System.out.println("Hey! Aqui toy! X2");
                }
            }
            while(numerosArchivoOriginalArregloDouble.get(t).size()<valorRecursivoMaximo){
                numerosArchivoOriginalArregloDouble.get(t).add(1,0.0);
                System.out.println("Arreglo Enteros Arreglado"+numerosArchivoOriginalArregloDouble.get(t));
            }
        }
    }
    
    public void ImprimeArregloDouble(){
        for(int j=0;j<numerosArchivoOriginalArregloDouble.size();j++){
            System.out.println(numerosArchivoOriginalString.get(j));
            for(int k=0; k<numerosArchivoOriginalArregloDouble.get(j).size();k++){
                System.out.println(numerosArchivoOriginalArregloDouble.get(j).get(k));         
            }
        }
    }
    
    public ArrayList<String> lecturaArchivo(String archivo, String nombreArchivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileWriter arch = new FileWriter(archivo,true);
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split(",");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueArchivoString.add((bloque[i]));
                    }
                }  
                System.out.println("Bloque " + nombreArchivo);
                for(String d : bloqueArchivoString){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux.close();
            arch.write("");
            arch.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
        
    public void radixSort(int posicionVerificando){
        double valor;
        try{
            
            FileReader lf0 = new FileReader(Q0);
            FileReader lf1 = new FileReader(Q1);
            FileReader lf2 = new FileReader(Q2);
            FileReader lf3 = new FileReader(Q3);
            FileReader lf4 = new FileReader(Q4);
            FileReader lf5 = new FileReader(Q5);
            FileReader lf6 = new FileReader(Q6);
            FileReader lf7 = new FileReader(Q7);
            FileReader lf8 = new FileReader(Q8);
            FileReader lf9 = new FileReader(Q9);
            
            BufferedReader blf0 = new BufferedReader(lf0);
            BufferedReader blf1 = new BufferedReader(lf1);
            BufferedReader blf2 = new BufferedReader(lf2);
            BufferedReader blf3 = new BufferedReader(lf3);
            BufferedReader blf4 = new BufferedReader(lf4);
            BufferedReader blf5 = new BufferedReader(lf5);
            BufferedReader blf6 = new BufferedReader(lf6);
            BufferedReader blf7 = new BufferedReader(lf7);
            BufferedReader blf8 = new BufferedReader(lf8);
            BufferedReader bf9 = new  BufferedReader(lf9);
            
            FileWriter f0 = new FileWriter(Q0,false);
            FileWriter f1 = new FileWriter(Q1,false);
            FileWriter f2 = new FileWriter(Q2,false);
            FileWriter f3 = new FileWriter(Q3,false);
            FileWriter f4 = new FileWriter(Q4,false);
            FileWriter f5 = new FileWriter(Q5,false);
            FileWriter f6 = new FileWriter(Q6,false);
            FileWriter f7 = new FileWriter(Q7,false);
            FileWriter f8 = new FileWriter(Q8,false);
            FileWriter f9 = new FileWriter(Q9,false);
            
            //Escribir los valores de los números en su respectivo archivo de acuerdo a la posición trabajada.
            for(int i=0; i<numerosArchivoOriginalArregloDouble.size(); i++){
                System.out.println("Valor verificando " + numerosArchivoOriginalArregloDouble.get(i).get(0).toString());
                System.out.println("Posicion Ver " + posicionVerificando);
                /*if(numerosArchivoOriginalArregloDouble.get(i).get(0).toString().length() < posicionVerificando){ //En caso de que el número que se encuentre trabajando sea muy corto.
                    f0.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                    f0.write(",");
                }
                else{*/
                    valor = numerosArchivoOriginalArregloDouble.get(i).get(posicionVerificando);
                    switch((int)valor){
                            case 0:
                                f0.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f0.write(",");
                                break;
                            case 1:
                                f1.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f1.write(",");
                                break;
                            case 2:
                                f2.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f2.write(",");
                                break;
                            case 3:
                                f3.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f3.write(",");
                                break;
                            case 4:
                                f4.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f4.write(",");
                                break;
                            case 5:
                                f5.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f5.write(",");
                                break;
                            case 6:
                                f6.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f6.write(",");
                                break;
                            case 7:
                                f7.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f7.write(",");
                                break;
                            case 8:
                                f8.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f8.write(",");
                                break;
                            case 9:
                                f9.write(String.valueOf(numerosArchivoOriginalArregloDouble.get(i).get(0)));
                                f9.write(",");
                                break;     
                    //}
                }
            }

            f0.close();
            f1.close();
            f2.close();
            f3.close();
            f4.close();
            f5.close();
            f6.close();
            f7.close();
            f8.close();
            f9.close();
        }catch(IOException e){
            System.out.println("ERROR DE ARCHIVO");
        }
    }
    
    public void pasarAOriginal(){
            Cola0 = lecturaArchivo(Q0, "0");
            Cola1 = lecturaArchivo(Q1, "1");
            Cola2 = lecturaArchivo(Q2, "2");
            Cola3 = lecturaArchivo(Q3, "3");
            Cola4 = lecturaArchivo(Q4, "4");
            Cola5 = lecturaArchivo(Q5, "5");
            Cola6 = lecturaArchivo(Q6, "6");
            Cola7 = lecturaArchivo(Q7, "7");
            Cola8 = lecturaArchivo(Q8, "8");
            Cola9 = lecturaArchivo(Q9, "9");
            vaciarColas(Cola0);
            vaciarColas(Cola1);
            vaciarColas(Cola2);
            vaciarColas(Cola3);
            vaciarColas(Cola4);
            vaciarColas(Cola5);
            vaciarColas(Cola6);
            vaciarColas(Cola7);
            vaciarColas(Cola8);
            vaciarColas(Cola9);
}
    
    public void vaciarColas(ArrayList<String> cola){
        try{
            FileWriter original = new FileWriter(nombreArchivoOriginal,true);
            while(!cola.isEmpty()){
                original.write(cola.remove(0));
                original.write(",");
            }
            original.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void ordenamiento(){
        crearArchivo(Q0, 0);
        crearArchivo(Q1, 1);
        crearArchivo(Q2, 2);
        crearArchivo(Q3, 3);
        crearArchivo(Q4, 4);
        crearArchivo(Q5, 5);
        crearArchivo(Q6, 6);
        crearArchivo(Q7, 7);
        crearArchivo(Q8, 8);
        crearArchivo(Q9, 9);
        lecturaOriginal();
        ValorRecursivoMaximo();
        ArregloDeArreglos();
        for(int basileKellerMartinez=valorRecursivoMaximo-1; basileKellerMartinez>1;basileKellerMartinez--){
            radixSort(basileKellerMartinez);
            pasarAOriginal();
            if(basileKellerMartinez!=2){
                lecturaOriginal();
                ArregloDeArreglos();
            }
        }
        bloqueArchivoOriginalString = lecturaArchivo(nombreArchivoOriginal, "Original");
    }
    
    public void crearArchivo(String nombre, int cola){
        try {
            FileWriter file = new FileWriter(nombre,false);
            file.close();
        } catch (IOException e) {
            System.out.println("ERROR AL CREAR EL ARCHIVO");
        }

    }
        
}