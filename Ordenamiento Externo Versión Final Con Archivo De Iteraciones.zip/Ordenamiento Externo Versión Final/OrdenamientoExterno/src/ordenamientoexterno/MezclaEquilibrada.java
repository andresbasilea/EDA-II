package ordenamientoexterno;

import java.util.*;
import java.io.*;

/**
* Implementa el método de ordenamiento externo por <b>mezcla equilibrada</b>. El método de ordenamiento
* por mezcla equilibrada implementado en esta clase permite ordenar archivos con números
* reales de hasta dos decimales separados por comas y sin espacios en blanco entre cada uno.
* Los archivos leídos pueden tener cualquier cantidad de claves y, en caso de ser requerido, podrán 
* generarse a partir del programa <b>generador.py</b> ubicado en la carpeta principal del programa.
* 
* <p>
* El método de ordenamiento por mezcla equilibrada consiste en realizar <b>particiones</b> o <b>bloques</b>
* tomando secuencias de máxima longitud (conocidas como "natural runs"). Estas secuencias de máxima longitud son 
* ubicadas en 2 archivos auxiliares "AuxiliarMezclaEquilibrada1.txt" y "AuxiliarMezclaEquilibrada2.txt", de donde serán
* leídas, ordenadas mediante un "merge" y ubicadas nuevamente en el archivo original, repitiendo el proceso hasta 
* que se obtenga una secuencia totalmente ordenada de números (ya sea de manera ascendente o descendente).
* </p>
* 
* @author Basile Álvarez Andrés, Keller Ascencio Rodolfo, Martínez Jiménez María Fernanda
*/
public class MezclaEquilibrada {
    String nombreArchivoOriginal;
    int tipoOrdenamiento;
    
    String bloque[];
    String numeros[];    
    String bloqueAux[];    
    String bloque1Original[];    
    String bloque1OriginalAux[];
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivo1String = new ArrayList<>();
    ArrayList<String> bloqueArchivo2String = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    
    static String nomAux1 = "AuxiliarMezclaEquilibrada1.txt";
    static String nomAux2 = "AuxiliarMezclaEquilibrada2.txt";
    static String procedimiento = "IteracionesMezclaEquilibrada.txt";
    
    /**
     * Método constructor de los objetos de la clase. Se pasa como parámetro el nombre del archivo que busca ordenarse (String)
     * con su debida extensión (.txt),así como un número entero que indica el tipo de ordenamiento a realizar (1 para ascendente o 2 para descendente).
     * El método constructor utiliza el nombre del archivo pasado como parámetro para abrirlo, leerlo y guardar todos los números
     * encontrados en él dentro de un arreglo de cadenas, <b>"numeros"</b>. Una vez encontrados allí, los números son pasados a un
     * ArrayList de elementos Double, <b>numerosDouble</b>, para su posterior uso durante la ejecución del programa. 
     * @param archivo
     * @param tipoOrdenamiento 
     */
    MezclaEquilibrada(String archivo, int tipoOrdenamiento){
        this.nombreArchivoOriginal = archivo;
        this.tipoOrdenamiento = tipoOrdenamiento;  
        try{
            FileReader lArchivo = new FileReader(nombreArchivoOriginal);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }      
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    /**
     * Este método de tipo <b>void</b> sin parámetros crea los dos archivos auxiliares del programa y divide 
     * a los elementos del ArrayList <b>numerosDouble</b> en bloques tomando secuencias ordenadas de máxima longitud de números 
     * y colocándolas en los archivos auxiliares conforme van apareciendo (la primer secuencia se ubica en el primer archivo, 
     * la segunda en el segundo, la tercera en el primero y así sucesivamente hasta terminar con todos los números dentro de <b>numerosDouble</b>).
     */
    public void bloques(){
        try{
            FileWriter archivoOriginal = new FileWriter(nombreArchivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1;
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }
            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    /**
     * Este método permite leer un archivo y guardar los elementos dividios por "/" en el arreglo de 
     * cadenas "bloque" para después ser agregados al ArrayList "bloqueArchivoString" y finalizar con un "/" que indica el fin
     * del bloque agregado al ArrayList.
     * @param archivo el nombre del archcivo a leer.
     * @return se regresa el <b>bloqueArchivoString</b>, ArrayList que contiene los elementos leídos del archivo.
     */
    public ArrayList<String> lecturaArchivo(String archivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split("/");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueAux = bloque[i].split(",");
                        for(int j=0; j<bloqueAux.length;j++){
                            bloqueArchivoString.add((bloqueAux[j]));
                        }
                        bloqueArchivoString.add("/");
                    }
                }  
            }
            laux.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
    
    /**
     * Este método de tipo <b>void</b> permite escribir de nuevo los elementos dentro de los bloques de los 
     * archivos uno y dos guardados en los ArrayList de tipo String <b>bloqueArchivo1String</b> y <b>bloqueArchivo2String</b>,
     * respectivamente. Los bloques son almacenados en el archivo original siguiendo el procedimiento: 
     * Se leen ambos archivos. Se compara el primer elemento del primer bloque con el primer elemento del segundo bloque.
     * El mayor de ellos es colocado en el archivo original y removido de su respectivo bloque. Se continúa hasta que alguno de los bloques
     * se encuentre vacío y finalmente se escriben en el archivo original los elementos restantes del bloque no vacío. 
     */
    public void escrituraBloquesArchivoOriginal(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombreArchivoOriginal,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))<Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo2String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * Este método de tipo <b>void</b> lee el archivo original nuevamente y ubica sus elementos 
     * en el arreglo de cadenas <b>bloqueOriginal</b>. Agrega los elementos leídos al ArrayList 
     * de cadenas <b>bloqueArchivoOriginalString</b> para su impresión en pantalla y su escritura 
     * en los archivos auxiliares 1 y 2 a manera de bloques.
     */
    public void leerArchivoOriginalPasarAAuxiliares(){
        try{
            FileReader archivoOriginal = new FileReader(nombreArchivoOriginal);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);
            FileWriter aux1 = new FileWriter(nomAux1,false);
            FileWriter aux2 = new FileWriter(nomAux2,false);
            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
                System.out.println("BloqueOriginal");
                for(String d : bloqueArchivoOriginalString){
                    System.out.println(d);
                }
                System.out.println();
                while(!bloqueArchivoOriginalString.isEmpty()){
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        aux1.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux1.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux1.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)!="/"){
                        aux2.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux2.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux2.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
            }
            bArchivoOriginal.close();
            aux1.close();
            aux2.close();
        }catch(IOException e){
            System.out.println("ERROR¿?");
        } 
    }
    
    /**
     * Este método de tipo <b>boolean</b> que no toma parámetros lee el ArrayList de cadenas 
     * <b>bloqueArchivoOriginalString</b> después de realizar el "merge" de los archivos auxiliares
     * y verifica si dentro de éste se encuentra el símbolo "/", el cual indica la división entre dos bloques
     * de números. El archivo se encontrará ordenado cuando haya únicamente uno o ningún "/" en el ArrayList 
     * leído. 
     * @return <b>true</b> en caso de que el archivo se encuentre ordenado o <b>false</b> en caso contrario. 
     */
    public boolean verificaOrdenamiento(){
        boolean verificaOrdenamiento = true;
        int contadLasLineas = 0;
        for(int m=0; m<bloqueArchivoOriginalString.size(); m++){
            if(bloqueArchivoOriginalString.get(m)=="/"){  
                contadLasLineas++;
            }
        } 
        if(contadLasLineas==1||contadLasLineas==0){
            verificaOrdenamiento = true;
        }
        else{
            verificaOrdenamiento=false;
        }
        bloqueArchivoOriginalString.clear();
        return verificaOrdenamiento;
    }
    
    /**
     * Método de tipo <b>void</b> que permite imprimir los elementos ubicados en un ArrayList.
     * @param nombreArchivo el nombre del archivo de donde proviene el bloque (puede ser cualquier cadena).
     * @param bloqueArchivoString el nombre del ArrayList de donde se leerán los elementos. 
     */
    public void impresionBloques(String nombreArchivo, ArrayList<String> bloqueArchivoString){
        try{
            FileWriter pro = new FileWriter(procedimiento,true);
            System.out.println("Bloque " + nombreArchivo);
            for(String d : bloqueArchivoString){
                System.out.println(d);
            }
            System.out.println();
            pro.write("****************************************\r\n");
            pro.write("Bloque " + nombreArchivo + "\r\n");
            for(String d : bloqueArchivoString){
                pro.write(d);
                pro.write(",");
            }
            pro.write("\r\n****************************************\r\n\r\n\r\n");
            pro.close();
        }
        catch(IOException e){
            System.out.println("ERROR AL ESCRIBIR EL ARCHIVO");
        }
    }
    
    /**
     * En este método de tipo <b>void</b> que no recibe ningún parámetro, se realiza la división de
     * bloques de manera descendente a partir de la lectura del archivo original. La división en bloques
     * se realiza a partir de secuencias ordenadas (en orden descendente) de máxima longitud y escritas 
     * en los archivos auxiliares 1 y 2 (de igual manera que en el método "bloques".
     */
    public void bloquesDescendente(){
        try{
            FileWriter archivoOriginal = new FileWriter(nombreArchivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)<numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1; 
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)<numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }
            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    /**
     * En este método de tipo <b>void</b> que no recibe ningún parámetro, se realiza la escritura de los
     * bloques de secuencias máximas de longitud en orden descendente ubicados en los archivo auxiliares 1
     * y 2 en el archivo original, separando cada elemento con "," y escrbiendo un "/" al finalizar el "merge"
     * de los bloques de los archivos auxiliares.  
     */
    public void escrituraBloquesArchivoOriginalDescendente(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombreArchivoOriginal,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))>Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                } 
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo1String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    /**
     * En este método de tipo <b>void</b> se realizan las operaciones necesarias para ordenar los elementos
     * dentro del archivo original en un orden específico. En caso de que se decida ordenar en forma 
     * ascendente, se llama a los métodos "lecturaArchivoAuxiliar" (1 y 2), "escrituraBloquesArchivoOriginal", 
     * "leerArchivoOriginalPasarAAuxiliares" y "lecturaArchivoOriginal" dentro de un ciclo <b>do-while</b> que se
     * realiza mientras el método "verificaOrdenamiento" devuelva el valor "false" (indicando que el archivo no se encuentra
     * ordenado todavía).
     * <p>En caso de que se decida ordenar de manera descendente, primero se llama al método "bloquesDescendente"
     * para generar los bloques en orden descendente. Dentro de un ciclo <b>do-while</b> se leen los archivos auxiliares 1 y 2
     * utilizando el método "lecturaArchivoAuxiliar", se escribe sobre el archivo original utilizando "escrituraBloquesArchivoOriginalDescendente",
     * se lee el archivo original y se pasa a los auxiliares nuevamente hasta que no se cumpla la condición 
     * "verificaOrdenamiento() == false".</p>
     */
    public void ordenamiento(){
        try{
            FileWriter borra = new FileWriter(procedimiento);
            borra.close();
            if(tipoOrdenamiento==1){
                bloques();
                int i = 1;
                do{
                    FileWriter pro = new FileWriter(procedimiento,true);
                    pro.write("\r\nIteración " + i + "\r\n");
                    pro.close();
                    bloqueArchivo1String = lecturaArchivo(nomAux1);
                    impresionBloques("1",bloqueArchivo1String);
                    bloqueArchivo2String = lecturaArchivo(nomAux2);
                    impresionBloques("2",bloqueArchivo2String);
                    escrituraBloquesArchivoOriginal();
                    leerArchivoOriginalPasarAAuxiliares();
                    bloqueArchivoOriginalString = lecturaArchivo(nombreArchivoOriginal);
                    impresionBloques("Original",bloqueArchivoOriginalString);
                    i++;
                }while(verificaOrdenamiento()==false);            
            }

            if(tipoOrdenamiento == 2){
               bloquesDescendente();
               int i = 1;
                do{
                    FileWriter pro = new FileWriter(procedimiento,true);
                    pro.write("\r\nIteración " + i + "\r\n");
                    pro.close();                    
                    bloqueArchivo1String = lecturaArchivo(nomAux1);
                    impresionBloques("1",bloqueArchivo1String);
                    bloqueArchivo2String = lecturaArchivo(nomAux2);
                    impresionBloques("2",bloqueArchivo2String);
                    escrituraBloquesArchivoOriginalDescendente();
                    leerArchivoOriginalPasarAAuxiliares();
                    bloqueArchivoOriginalString = lecturaArchivo(nombreArchivoOriginal);
                    impresionBloques("Original",bloqueArchivoOriginalString);
                    i++;
                }while(verificaOrdenamiento()==false); 
            }
        }
        catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO DE ITERACIONES");
        }
    }
    
}
