package ordenamientoexterno;
import java.util.*;

/**
 * Esta clase contiene el método <b>main</b> que permite ordenar un archivo de <b>n</b> claves (números reales de hasta dos decimales) utilizando un algoritmo de ordenamiento externo. 
 * Las posibles opciones de ordenamiento para escoger son:
 * <p>Ordenamiento por polifase</p> <p>Ordenamiento por mezcla equilibrada</p> <p>Ordenamiento por distribución</p>
 * 
 * @author Basile Álvarez Andrés, Keller Ascencio Rodolfo, Martínez Jiménez María Fernanda.
 */
public class OrdenamientoExterno {
    static Scanner sc = new Scanner(System.in);
    
    /**
     * En este método, principal del programa, se imprime un menú que permite al usuario escoger entre las opciones de ordenamiento. Se pueden ordenar tantos archivos como el usuario lo
     * desee, siempre y cuando se ordene uno por uno y tomando en cuenta las características que dichos archivos deben poseer. 
     * @param args 
     */
    public static void main(String[] args){
        System.out.println("\nORDENAMIENTO EXTERNO\n\nBienvenido al programa de ordenamiento externo de archivos\n***\nCreadores:\n\tBasile Álvarez Andrés José\n\tKeller Ascencio Rodolfo Andrés\n\tMartínez Jiménez María Fernanda\n***\n");
        int opc = 1;
        while(opc>0 && opc<4){
            System.out.println("\n\n¿Qué método de ordenamiento desea utilizar?\n1)Método por polifase \n2)Método por mezcla equilibrada \n3)Método por distribución (radix)\n4)Salir\nIngrese: ");
            opc = sc.nextInt();
            switch(opc){
                case 1:
                    sc.nextLine();
                    System.out.println("Debe ingresar el nombre del archivo a ordenar ***EL NOMBRE DEBE INCLUIR LA EXTENSIÓN DEL ARCHIVO (.txt)***\nIngrese: ");
                    String nombreArchivo = sc.nextLine();
                    System.out.println("Ingrese el tipo de ordenamiento deseado: \n1)Ascendente\n2)Descendente\nIngrese: ");
                    int tipo = sc.nextInt();
                    if(tipo!=1&&tipo!=2){
                        System.out.println("Tipo de ordenamiento inválido, favor de ingresar una opción correcta");
                        break;
                    }
                    System.out.println("Ingrese el número de claves para los bloques del ordenamiento por Polifase");
                    int claves=sc.nextInt();
                    Polifase polifase = new Polifase(nombreArchivo,tipo,claves);
                    polifase.ordenamiento();
                    break;
                case 2:
                    sc.nextLine();
                    System.out.println("Debe ingresar el nombre del archivo a ordenar ***EL NOMBRE DEBE INCLUIR LA EXTENSIÓN DEL ARCHIVO (.txt)***\nIngrese: ");
                    nombreArchivo = sc.nextLine();
                    System.out.println("Ingrese el tipo de ordenamiento deseado: \n1)Ascendente\n2)Descendente\nIngrese: ");
                    tipo = sc.nextInt();
                    if(tipo!=1&&tipo!=2){
                        System.out.println("Tipo de ordenamiento inválido, favor de ingresar una opción correcta");
                        break;
                    }
                    MezclaEquilibrada mezclaEquilibrada = new MezclaEquilibrada(nombreArchivo,tipo);
                    mezclaEquilibrada.ordenamiento();
                    break;
                case 3:
                    sc.nextLine();
                    System.out.println("Debe ingresar el nombre del archivo a ordenar ***EL NOMBRE DEBE INCLUIR LA EXTENSIÓN DEL ARCHIVO (.txt)***\nIngrese: ");
                    nombreArchivo = sc.nextLine();
                    System.out.println("Ingrese el tipo de ordenamiento deseado: \n1)Ascendente\n2)Descendente\nIngrese: ");
                    tipo = sc.nextInt();
                    if(tipo!=1&&tipo!=2){
                        System.out.println("Tipo de ordenamiento inválido, favor de ingresar una opción correcta");
                        break;
                    }
                    Distribucion distribucion = new Distribucion(nombreArchivo,tipo);
                    distribucion.ordenamiento();
                    break;
                default:
                    break;      
            }
        }
    }
    
}
