package ordenamientoexterno;
import java.util.*;

/**
* Esta clase implementa el método de ordenamiento interno <b>QuickSort</b>. La clase <b>QuickSort</b> 
* es una clase auxiliar que nos ayuda a ordenar números provenientes de un <b>ArrayList de tipo Double</b>
* de forma ascendente o descendente mediante el uso del método que lleva por nombre la clase.
* 
* <p>
* El método de ordenamiento QuickSort consiste en hacer uso de un elemento <b>pivote</b> para que, a partir de
* este elemento se vayan comparando cada uno de los elementos contenidos dentro de nuestra lista y al evaluarlos
* se verifique si son mayores o menores al valor pivote, en caso de ser mayores o iguales al valor del pivote, 
* los elementos deberán acomodarse* del lado derecho de este; en caso de ser menores, deberán colocarse del lado izquierdo.
* </p>
* 
* @author Basile Álvarez Andrés, Keller Ascencio Rodolfo, Martínez Jiménez María Fernanda
*/
public class Quicksort {
    
    /**
     * Este método devuelve como valor retorno una <b>posición int</b> recibiendo como parámetros el <b>arreglo a ordenar</b>
     * y las <b>posiciones</b> del intervalo de los valores dentro del arreglo con los que se va a trabajar.
     * 
     * <p>
     * Dentro de este método, se toma el elemento de la última posición dentro del rango a evaluar como pivote y a partir de éste,
     * se van evaluando cada uno de los elementos dentro del arreglo para este pivote, para que, de esta manera, se vayan comparando 
     * los elementos y se tenga la certeza de que todos los elementos mayores o iguales al valor del elemento evaluado estén posicionados
     * del lado derecho del pivote, y todos los elementos menores estén posicionados del lado izquierdo.
     * </p>
     * 
     * @param arr el nombre del arreglo a ordenar.
     * @param low el menor de los valores de la posición del arreglo a evaluar.
     * @param high el mayor de los valores de la posición del arreglo a evaluar.
     * @return se regresa la <b>posición</b> consecuente a la menor posición evaluada dentro del arreglo.
     */
    int partitionAscendente(ArrayList<Double> arr, int low, int high){
        int pivot = high;
        int j,i=low-1;
        for(j=low;j<high; j++){
            if(arr.get(j)<= arr.get(pivot)){
                i++;
                double temp = arr.get(i);
    	        arr.set(i,arr.get(j));
    	        arr.set(j,temp);
            }
        }
        double temp = arr.get(i+1);
        arr.set(i+1,arr.get(high));
        arr.set(high,temp);
        return i+1;
    }

    /**
     * Este método de tipo <b>void</b> recibe como parámetros el <b>arreglo a ordenar</b> y las <b>posiciones</b> del intervalo de 
     * los valores dentro del arreglo con los que se va a trabajar.
     * 
     * <p>
     * Dentro de este método, se va a realizar el método de <b>QuickSort</b> ascendente mientras no se haya sobrepasado el intervalo a evaluar.
     * Se va a recibir un valor entero a partir del método <b>"partitionAscendente"</b>, el cual representa el valor de la posición
     * a partir de la cual se va a ir realizando el ordenamiento; a partir de este valor se vuelve a llamar a esta función de forma 
     * recursiva dado que se dividió  el arreglo en dos subarreglos, ordenando los subarreglos del lado izquierdo del pivote, y del 
     * lado derecho del mismo.
     * </p>
     * 
     * @param arr el nombre del arreglo a ordenar.
     * @param low el menor de los valores de la posición del arreglo a evaluar.
     * @param high el mayor de los valores de la posición del arreglo a evaluar.
     */    
    void sortAscendente(ArrayList<Double> arr, int low, int high){
        if(low<high){
            int pi = partitionAscendente(arr, low, high);
            sortAscendente(arr,low,pi-1);
            sortAscendente(arr,pi+1,high);
        }
    }
    
    /**
     * Este método devuelve como valor retorno una <b>posición int</b> recibiendo como parámetros el <b>arreglo a ordenar</b>
     * y las <b>posiciones</b> del intervalo de los valores dentro del arreglo con los que se va a trabajar.
     * 
     * <p>
     * Dentro de este método, se toma el elemento de la última posición dentro del rango a evaluar como pivote y a partir de éste,
     * se van evaluando cada uno de los elementos dentro del arreglo para este pivote, para que, de esta manera, se vayan comparando 
     * los elementos y se tenga la certeza de que todos los elementos menores o iguales al valor del elemento evaluado estén posicionados
     * del lado derecho del pivote, y todos los elementos mayores estén posicionados del lado izquierdo.
     * </p>
     * 
     * @param arr el nombre del arreglo a ordenar.
     * @param low el menor de los valores de la posición del arreglo a evaluar.
     * @param high el mayor de los valores de la posición del arreglo a evaluar.
     * @return se regresa la <b>posición</b> consecuente a la menor posición evaluada dentro del arreglo.
     */
    int partitionDescendente(ArrayList<Double> arr, int low, int high){
        int pivot = high;
        int j,i=low-1;
        for(j=low;j<high; j++){
            if(arr.get(j)>= arr.get(pivot)){
                i++;
                double temp = arr.get(i);
    	        arr.set(i,arr.get(j));
    	        arr.set(j,temp);
            }
        }
        double temp = arr.get(i+1);
        arr.set(i+1,arr.get(high));
        arr.set(high,temp);
        return i+1;
    }

    /**
     * Este método de tipo <b>void</b> recibe como parámetros el <b>arreglo a ordenar</b> y las <b>posiciones</b> del intervalo de 
     * los valores dentro del arreglo con los que se va a trabajar.
     * 
     * <p>
     * Dentro de este método, se va a realizar el método de <b>QuickSort</b> descendente mientras no se haya sobrepasado el intervalo a evaluar.
     * Se va a recibir un valor entero a partir del método <b>"partitionDescendente"</b>, el cual representa el valor de la posición
     * a partir de la cual se va a ir realizando el ordenamiento; a partir de este valor se vuelve a llamar a esta función de forma 
     * recursiva dado que se dividió  el arreglo en dos subarreglos, ordenando los subarreglos del lado izquierdo del pivote, y del 
     * lado derecho del mismo.
     * </p>
     * 
     * @param arr el nombre del arreglo a ordenar.
     * @param low el menor de los valores de la posición del arreglo a evaluar.
     * @param high el mayor de los valores de la posición del arreglo a evaluar.
     */   
    void sortDescendente(ArrayList<Double> arr, int low, int high){
        if(low<high){
            int pi = partitionDescendente(arr, low, high);
            sortDescendente(arr,low,pi-1);
            sortDescendente(arr,pi+1,high);
        }
    }
}
