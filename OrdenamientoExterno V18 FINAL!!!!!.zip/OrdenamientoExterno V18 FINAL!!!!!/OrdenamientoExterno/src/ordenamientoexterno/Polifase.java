package ordenamientoexterno;
import java.util.*;
import java.io.*;

public class Polifase {

    String archivoOriginal;
    int tipoOrdenamiento;
    int claves;
    String numeros[];
    String bloque[];
    String bloqueAux[];
    
    Quicksort sort = new Quicksort();
    boolean bloquesNoCompletos = false;
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<Double> numerosDouble1 = new ArrayList<>();
    ArrayList<Double> numerosDouble2 = new ArrayList<>();
    ArrayList<String> bloqueArchivo1String = new ArrayList<>();
    ArrayList<String> bloqueArchivo2String = new ArrayList<>();
    ArrayList<String> bloqueArchivo3String = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    
    static String nomAux1 = "AuxiliarPolifase1.txt";
    static String nomAux2 = "AuxiliarPolifase2.txt";
    static String nomAux3 = "AuxiliarPolifase3.txt";
    
    Polifase(String nombre, int tipoOrdenamiento, int claves){
        this.tipoOrdenamiento = tipoOrdenamiento;
        this.archivoOriginal = nombre;
        this.claves = claves;
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    public void fase1BloquesAscendente(){
        try{
            FileWriter archOriginal = new FileWriter(archivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int termina = 1;
            while(claves<numerosDouble.size()){
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble1.add(numerosDouble.remove(0).doubleValue());
                            termina=1;
                        }
                    }
                    sort.sortAscendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    while(!numerosDouble1.isEmpty()){                            
                        aux1.write(numerosDouble1.remove(0).toString());
                        if(!numerosDouble1.isEmpty()){
                            aux1.write(",");
                        }
                    }
                    aux1.write("/");
                }
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble2.add(numerosDouble.remove(0).doubleValue());
                            termina=2;
                        }
                    }
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    while(!numerosDouble2.isEmpty()){                            
                        aux2.write(numerosDouble2.remove(0).toString());
                        if(!numerosDouble2.isEmpty()){
                            aux2.write(",");
                        }
                    }
                    aux2.write("/");
                }
            }
            while(!numerosDouble.isEmpty()){
                if(termina == 1){
                    numerosDouble2.add(numerosDouble.remove(0).doubleValue());
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux2.write(numerosDouble2.remove(0).toString());
                    if(!numerosDouble.isEmpty()){
                        aux2.write(",");
                    }
                }
                if(termina == 2){
                    numerosDouble1.add(numerosDouble.remove(0).doubleValue());
                }
                bloquesNoCompletos=true;
            }
            if(termina == 1 && bloquesNoCompletos==true){
                while(!numerosDouble2.isEmpty()){
                    sort.sortAscendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux1.write(numerosDouble2.remove(0).toString());
                    if(!numerosDouble2.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux2.write("/");                 
            }
            if(termina == 2 && bloquesNoCompletos==true){
                while(!numerosDouble1.isEmpty()){
                    sort.sortAscendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    aux1.write(numerosDouble1.remove(0).toString());
                    if(!numerosDouble1.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux1.write("/");                  
            }
            aux1.close();
            aux2.close();
            archOriginal.write("");
            archOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    public void fase1BloquesDescendente(){
        Quicksort sort = new Quicksort();
        try{
            FileWriter archOriginal = new FileWriter(archivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int termina = 1;
            while(claves<numerosDouble.size()){
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble1.add(numerosDouble.remove(0).doubleValue());
                            termina=1;
                        }
                    }
                    sort.sortDescendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    while(!numerosDouble1.isEmpty()){                            
                        aux1.write(numerosDouble1.remove(0).toString());
                        if(!numerosDouble1.isEmpty()){
                            aux1.write(",");
                        }
                    }
                    aux1.write("/");
                }
                if(claves<numerosDouble.size()){
                    for(int r=0; r<claves;r++){
                        if(!numerosDouble.isEmpty()){
                            numerosDouble2.add(numerosDouble.remove(0).doubleValue());
                            termina=2;
                        }
                    }
                    sort.sortDescendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    while(!numerosDouble2.isEmpty()){                            
                        aux2.write(numerosDouble2.remove(0).toString());
                        if(!numerosDouble2.isEmpty()){
                            aux2.write(",");
                        }
                    }
                    aux2.write("/");
                }
            }
            while(!numerosDouble.isEmpty()){
                if(termina == 1){
                    numerosDouble2.add(numerosDouble.remove(0).doubleValue());
                    sort.sortDescendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux2.write(numerosDouble2.remove(0).toString());
                    if(!numerosDouble.isEmpty()){
                        aux2.write(",");
                    }
                }
                if(termina == 2){
                    numerosDouble1.add(numerosDouble.remove(0).doubleValue());
                }
                bloquesNoCompletos=true;
            }
            if(termina == 1 && bloquesNoCompletos==true){
                while(!numerosDouble2.isEmpty()){
                    sort.sortDescendente(numerosDouble2, 0, numerosDouble2.size()-1);
                    aux1.write(numerosDouble2.remove(0).toString());
                    if(!numerosDouble2.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux2.write("/");                 
            }
            if(termina == 2 && bloquesNoCompletos==true){
                while(!numerosDouble1.isEmpty()){
                    sort.sortDescendente(numerosDouble1, 0, numerosDouble1.size()-1);
                    aux1.write(numerosDouble1.remove(0).toString());
                    if(!numerosDouble1.isEmpty()){
                        aux1.write(",");
                    }
                }
                aux1.write("/");                  
            }
            aux1.close();
            aux2.close();
            archOriginal.write("");
            archOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
       
    public ArrayList<String> lecturaArchivo(String archivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split("/");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueAux = bloque[i].split(",");
                        for(int j=0; j<bloqueAux.length;j++){
                            bloqueArchivoString.add((bloqueAux[j]));
                        }
                        bloqueArchivoString.add("/");
                    }
                }  
            }
            laux.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
    
    public void impresionBloques(String nombreArchivo, ArrayList<String> bloqueArchivoString){
        System.out.println("Bloque " + nombreArchivo);
        for(String d : bloqueArchivoString){
            System.out.println(d);
        }
        System.out.println();
    }
    
    public void escrituraBloquesArchivoOriginalyTercerArchivoAscendente(){
        try{
            FileWriter archivoOriginal1 = new FileWriter(archivoOriginal,false);
            FileWriter archivoAux3 = new FileWriter(nomAux3,false);
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo2String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){    
                    while(bloqueArchivo1String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo1String.remove(0)));
                    }
                    bloqueArchivo1String.remove(0);
                }
                if(!bloqueArchivo2String.isEmpty()){ 
                    while(bloqueArchivo2String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo2String.remove(0)));
                    }
                    bloqueArchivo2String.remove(0);
                }
                    sort.sortAscendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoOriginal1.write(numerosDouble.remove(0).toString());
                        archivoOriginal1.write(",");
                    }
                    archivoOriginal1.write("/");
                if(!bloqueArchivo1String.isEmpty()){ 
                    if(!bloqueArchivo1String.isEmpty()){
                        while(bloqueArchivo1String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo1String.remove(0)));
                        }
                        bloqueArchivo1String.remove(0);
                    }
                }
                if(!bloqueArchivo2String.isEmpty()){ 
                    if(!bloqueArchivo2String.isEmpty()){
                        while(bloqueArchivo2String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo2String.remove(0)));
                        }
                        bloqueArchivo2String.remove(0);
                    }
                }
                    sort.sortAscendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux3.write(numerosDouble.remove(0).toString());
                        archivoAux3.write(",");
                    }
                    archivoAux3.write("/");
            }
            archivoOriginal1.close();
            archivoAux3.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void escrituraBloquesArchivoOriginalyTercerArchivoDescendente(){
        try{
            FileWriter archivoOriginal1 = new FileWriter(archivoOriginal,false);
            FileWriter archivoAux3 = new FileWriter(nomAux3,false);
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo2String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){    
                    while(bloqueArchivo1String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo1String.remove(0)));
                    }
                    bloqueArchivo1String.remove(0);
                }
                if(!bloqueArchivo2String.isEmpty()){ 
                    while(bloqueArchivo2String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo2String.remove(0)));
                    }
                    bloqueArchivo2String.remove(0);
                }
                    sort.sortDescendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoOriginal1.write(numerosDouble.remove(0).toString());
                        archivoOriginal1.write(",");
                    }
                    archivoOriginal1.write("/");
                if(!bloqueArchivo1String.isEmpty()){ 
                    if(!bloqueArchivo1String.isEmpty()){
                        while(bloqueArchivo1String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo1String.remove(0)));
                        }
                        bloqueArchivo1String.remove(0);
                    }
                }
                if(!bloqueArchivo2String.isEmpty()){ 
                    if(!bloqueArchivo2String.isEmpty()){
                        while(bloqueArchivo2String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo2String.remove(0)));
                        }
                        bloqueArchivo2String.remove(0);
                    }
                }
                    sort.sortDescendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux3.write(numerosDouble.remove(0).toString());
                        archivoAux3.write(",");
                    }
                    archivoAux3.write("/");
            }
            archivoOriginal1.close();
            archivoAux3.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void escrituraBloquesAuxiliaresAscendente(){
        try{
            FileWriter archivoAux1 = new FileWriter(nomAux1,false);
            FileWriter archivoAux2 = new FileWriter(nomAux2,false);
            while(!bloqueArchivoOriginalString.isEmpty()||!bloqueArchivo3String.isEmpty()){
                if(!bloqueArchivoOriginalString.isEmpty()){    
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivoOriginalString.remove(0)));
                    }
                    bloqueArchivoOriginalString.remove(0);
                }
                if(!bloqueArchivo3String.isEmpty()){ 
                    while(bloqueArchivo3String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo3String.remove(0)));
                    }
                    bloqueArchivo3String.remove(0);
                }
                    sort.sortAscendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux1.write(numerosDouble.remove(0).toString());
                        archivoAux1.write(",");
                    }
                    archivoAux1.write("/");
                if(!bloqueArchivoOriginalString.isEmpty()){ 
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        while(bloqueArchivoOriginalString.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivoOriginalString.remove(0)));
                        }
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
                if(!bloqueArchivo3String.isEmpty()){ 
                    if(!bloqueArchivo3String.isEmpty()){
                        while(bloqueArchivo3String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo3String.remove(0)));
                        }
                        bloqueArchivo3String.remove(0);
                    }
                }
                    sort.sortAscendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux2.write(numerosDouble.remove(0).toString());
                        archivoAux2.write(",");
                    }
                    archivoAux2.write("/");
            }
            archivoAux1.close();
            archivoAux2.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void escrituraBloquesAuxiliaresDescendente(){
        try{
            FileWriter archivoAux1 = new FileWriter(nomAux1,false);
            FileWriter archivoAux2 = new FileWriter(nomAux2,false);
            while(!bloqueArchivoOriginalString.isEmpty()||!bloqueArchivo3String.isEmpty()){
                if(!bloqueArchivoOriginalString.isEmpty()){    
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivoOriginalString.remove(0)));
                    }
                    bloqueArchivoOriginalString.remove(0);
                }
                if(!bloqueArchivo3String.isEmpty()){ 
                    while(bloqueArchivo3String.get(0)!="/"){
                        numerosDouble.add(Double.parseDouble(bloqueArchivo3String.remove(0)));
                    }
                    bloqueArchivo3String.remove(0);
                }
                    sort.sortDescendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux1.write(numerosDouble.remove(0).toString());
                        archivoAux1.write(",");
                    }
                    archivoAux1.write("/");
                if(!bloqueArchivoOriginalString.isEmpty()){ 
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        while(bloqueArchivoOriginalString.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivoOriginalString.remove(0)));
                        }
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
                if(!bloqueArchivo3String.isEmpty()){ 
                    if(!bloqueArchivo3String.isEmpty()){
                        while(bloqueArchivo3String.get(0)!="/"){
                            numerosDouble.add(Double.parseDouble(bloqueArchivo3String.remove(0)));
                        }
                        bloqueArchivo3String.remove(0);
                    }
                }
                    sort.sortDescendente(numerosDouble, 0, numerosDouble.size()-1); 
                    while(!numerosDouble.isEmpty()){
                        archivoAux2.write(numerosDouble.remove(0).toString());
                        archivoAux2.write(",");
                    }
                    archivoAux2.write("/");
            }
            archivoAux1.close();
            archivoAux2.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void fase2OrdenamientoAscendente(){
        do{
            bloqueArchivo1String = lecturaArchivo(nomAux1);
            impresionBloques("1",bloqueArchivo1String);
            bloqueArchivo2String = lecturaArchivo(nomAux2);
            impresionBloques("2",bloqueArchivo2String);
            escrituraBloquesArchivoOriginalyTercerArchivoAscendente();
            bloqueArchivo3String = lecturaArchivo(nomAux3);
            if(!bloqueArchivo3String.isEmpty()){
                bloqueArchivo3String.clear();
                bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
                impresionBloques("Original",bloqueArchivoOriginalString);
                bloqueArchivo3String = lecturaArchivo(nomAux3);
                impresionBloques("3",bloqueArchivo3String);
                escrituraBloquesAuxiliaresAscendente();
            }
        }while(verificaOrdenamiento()==false);
    }
    
    public void fase2OrdenamientoDescendente(){
        do{
            bloqueArchivo1String = lecturaArchivo(nomAux1);
            impresionBloques("1",bloqueArchivo1String);
            bloqueArchivo2String = lecturaArchivo(nomAux2);
            impresionBloques("2",bloqueArchivo2String);
            escrituraBloquesArchivoOriginalyTercerArchivoDescendente();
            bloqueArchivo3String = lecturaArchivo(nomAux3);
            if(!bloqueArchivo3String.isEmpty()){
                bloqueArchivo3String.clear();
                bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
                impresionBloques("Original",bloqueArchivoOriginalString);
                bloqueArchivo3String = lecturaArchivo(nomAux3);
                impresionBloques("3",bloqueArchivo3String);
                escrituraBloquesAuxiliaresDescendente();
            }
        }while(verificaOrdenamiento()==false);
    }
    
    public boolean verificaOrdenamiento(){
        bloqueArchivo3String = lecturaArchivo(nomAux3);
        bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
        boolean verificaOrdenamiento = true;
        int contadLasLineas = 0;
        int contadLasLineas3 = 0;
        for(int m=0; m<bloqueArchivoOriginalString.size(); m++){
            if(bloqueArchivoOriginalString.get(m)=="/"){  
                contadLasLineas++;
            }
        } 
        for(int m=0; m<bloqueArchivo3String.size(); m++){
            if(bloqueArchivo3String.get(m)=="/"){  
                contadLasLineas3++;
            }
        } 
        if((contadLasLineas==1||contadLasLineas==0)&&(contadLasLineas3==0)){
            verificaOrdenamiento = true;
        }
        else{
            verificaOrdenamiento=false;
        }
        bloqueArchivoOriginalString.clear();
        bloqueArchivo3String.clear();
        System.out.println(verificaOrdenamiento);
        return verificaOrdenamiento;
    }
    
    public void ordenamiento(){
        if(tipoOrdenamiento==1){
            fase1BloquesAscendente();
            fase2OrdenamientoAscendente();
            bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
            impresionBloques("Original",bloqueArchivoOriginalString);
        }
        
        if(tipoOrdenamiento == 2){
            fase1BloquesDescendente();
            fase2OrdenamientoDescendente();
            bloqueArchivoOriginalString = lecturaArchivo(archivoOriginal);
            impresionBloques("Original",bloqueArchivoOriginalString);
        }
    }
    
}
