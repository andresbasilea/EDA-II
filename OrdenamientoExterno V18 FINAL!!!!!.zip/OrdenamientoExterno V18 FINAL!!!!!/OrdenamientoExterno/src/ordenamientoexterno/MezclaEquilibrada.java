package ordenamientoexterno;

import java.util.*;
import java.io.*;

public class MezclaEquilibrada {
    String nombreArchivoOriginal;
    int tipoOrdenamiento;
    
    String bloque[];
    String numeros[];    
    String bloqueAux[];    
    String bloque1Original[];    
    String bloque1OriginalAux[];
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivo1String = new ArrayList<>();
    ArrayList<String> bloqueArchivo2String = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    
    static String nomAux1 = "AuxiliarMezclaEquilibrada1.txt";
    static String nomAux2 = "AuxiliarMezclaEquilibrada2.txt";
    
    MezclaEquilibrada(String archivo, int tipoOrdenamiento){
        this.nombreArchivoOriginal = archivo;
        this.tipoOrdenamiento = tipoOrdenamiento;  
        try{
            FileReader lArchivo = new FileReader(nombreArchivoOriginal);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }      
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    public void bloques(){
        try{
            FileWriter archivoOriginal = new FileWriter(nombreArchivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1;
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }
            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    public ArrayList<String> lecturaArchivoAuxiliar(String archivo, String nombreArchivo){
        ArrayList<String> bloqueArchivoString = new ArrayList<>();
        try{
            FileReader laux = new FileReader(archivo); 
            BufferedReader blaux1 = new BufferedReader(laux);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque = numero.split("/");
                for(int i = 0;i<bloque.length;i++){
                    if(bloque[i]!=null){
                        bloqueAux = bloque[i].split(",");
                        for(int j=0; j<bloqueAux.length;j++){
                            bloqueArchivoString.add((bloqueAux[j]));
                        }
                        bloqueArchivoString.add("/");
                    }
                }  
                System.out.println("Bloque " + nombreArchivo);
                for(String d : bloqueArchivoString){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
        return bloqueArchivoString;
    }
    
    public void escrituraBloquesArchivoOriginal(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombreArchivoOriginal,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))<Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo2String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void leerArchivoOriginalPasarAAuxiliares(){
        try{
            FileReader archivoOriginal = new FileReader(nombreArchivoOriginal);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);
            FileWriter aux1 = new FileWriter(nomAux1,false);
            FileWriter aux2 = new FileWriter(nomAux2,false);
            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
                System.out.println("BloqueOriginal");
                for(String d : bloqueArchivoOriginalString){
                    System.out.println(d);
                }
                System.out.println();
                while(!bloqueArchivoOriginalString.isEmpty()){
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        aux1.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux1.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux1.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)!="/"){
                        aux2.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux2.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux2.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
            }
            bArchivoOriginal.close();
            aux1.close();
            aux2.close();
        }catch(IOException e){
            System.out.println("ERROR¿?");
        } 
    }
    
    public boolean verificaOrdenamiento(){
        boolean verificaOrdenamiento = true;
        int contadLasLineas = 0;
        for(int m=0; m<bloqueArchivoOriginalString.size(); m++){
            if(bloqueArchivoOriginalString.get(m)=="/"){  
                contadLasLineas++;
            }
        } 
        if(contadLasLineas==1||contadLasLineas==0){
            verificaOrdenamiento = true;
        }
        else{
            verificaOrdenamiento=false;
        }
        bloqueArchivoOriginalString.clear();
        return verificaOrdenamiento;
    }
    
    public void lecturaArchivoOriginal(){
        try{
            FileReader archivoOriginal = new FileReader(nombreArchivoOriginal);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);
            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
            }
            bArchivoOriginal.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void bloquesDescendente(){
        try{
            FileWriter archivoOriginal = new FileWriter(nombreArchivoOriginal,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)<numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1; 
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)<numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }
            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    public void escrituraBloquesArchivoOriginalDescendente(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombreArchivoOriginal,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))>Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                } 
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo1String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void ordenamiento(){
        if(tipoOrdenamiento==1){
            bloques();
            do{
                bloqueArchivo1String = lecturaArchivoAuxiliar(nomAux1, "1");
                bloqueArchivo2String = lecturaArchivoAuxiliar(nomAux2, "2");
                escrituraBloquesArchivoOriginal();
                leerArchivoOriginalPasarAAuxiliares();
                lecturaArchivoOriginal();
            }while(verificaOrdenamiento()==false);            
        }
        
        if(tipoOrdenamiento == 2){
           bloquesDescendente();
            do{
                bloqueArchivo1String = lecturaArchivoAuxiliar(nomAux1, "1");
                bloqueArchivo2String = lecturaArchivoAuxiliar(nomAux2, "2");
                escrituraBloquesArchivoOriginalDescendente();
                leerArchivoOriginalPasarAAuxiliares();
                lecturaArchivoOriginal();
            }while(verificaOrdenamiento()==false); 
        }
    }
    
}
