import random
archivo = open("archivo.txt","w")
for i in range(0,1000):
	n = round(random.uniform(0.0,100000.0),2)
	n = str(n)
	archivo.write(n)
	archivo.write(",")
archivo.sort()
archivo.close()