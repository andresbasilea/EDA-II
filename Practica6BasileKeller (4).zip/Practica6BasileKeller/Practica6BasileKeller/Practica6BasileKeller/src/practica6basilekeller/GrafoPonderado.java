package practica6basilekeller;
import java.util.*;

public class GrafoPonderado {
    int V;
    LinkedList<LinkedHashMap<Integer, Integer>> adjArray[];
    GrafoPonderado(int v){
        V = v;
        adjArray = new LinkedList[v]; 
        for (int i=0; i<v; ++i)
            adjArray[i] = new LinkedList<LinkedHashMap<Integer,Integer>>();
    }
    
    void addEdge(int origen ,int destino, int valor){
            LinkedHashMap<Integer, Integer> llDest = new LinkedHashMap<Integer,Integer>();
            llDest.put(destino,valor);
            adjArray[origen].add(llDest);
        } 

    void printGraph(GrafoPonderado graph){
        for(int v = 0; v < graph.V; v++){
            System.out.println("Lista de Adyacencia del vertice "+ v); 
            System.out.println(v);
            for (Iterator<LinkedHashMap<Integer, Integer>> it = graph.adjArray[v].iterator(); it.hasNext();) {
                System.out.print(" -> " + it.next());
            }
            System.out.println("\n");
        }
    } 
      
}
