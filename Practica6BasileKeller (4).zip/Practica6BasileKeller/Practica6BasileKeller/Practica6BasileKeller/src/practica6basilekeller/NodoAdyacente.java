package practica6basilekeller;

public class NodoAdyacente {
    int valor;
    int nodoOrigen;
    int nodoDestino;

    public NodoAdyacente(int nodoOrigen, int nodoDestino, int valor) {
        this.nodoOrigen = nodoOrigen;
        this.nodoDestino = nodoDestino;
        this.valor = valor;
    }
    
    public NodoAdyacente(){
    }
    
    public void imprimir(){
        System.out.println("Nodo Origen: " + this.nodoOrigen + " Nodo Destino: " + this.nodoDestino + " Valor: " + this.valor);
    }
    
}
