package practica6basilekeller;
import java.util.*;

public class ListaNodosAdyacentesVertice {
    public LinkedList<NodoAdyacente> nodosadyacentes = new LinkedList<>();

    public ListaNodosAdyacentesVertice(){
        this.nodosadyacentes = new LinkedList<>();
    }

    public void agregarNodo(NodoAdyacente nodo){
        this.nodosadyacentes.add(nodo);
    }
    
    public NodoAdyacente sacarNodo(){
        return nodosadyacentes.poll();
    }
    
}
