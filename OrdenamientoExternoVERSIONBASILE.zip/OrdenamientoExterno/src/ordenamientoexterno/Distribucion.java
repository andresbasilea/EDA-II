package ordenamientoexterno;
import java.util.*;
import java.io.*;
/**
 *
 * @author AndresBasile
 */
public class Distribucion {
    /* 10 archivos como colas
    
    
    1) Leer archivo y pasarlo a arreglo. 
    1.1) 
    1.5) verificar mediante bubble sort que el arreglo se encuentre ordenado, en caso de que asi sea, indicar que el archivo ya esta ordenado y salir. 
    2) Hacer arreglo de arreglos y almacenar los String en forma de arreglo 
    3) Utilizar ciclos for anidados del tamano del arreglo el primero y del tamano del numero el segundo... Utilizando una verificacion if se controla que los caracteres de los arreglos se encuentren en codigo ascii entre el 30 y el 39 ***para pasarlo a entero***
       y en caso de no cumplir que se pase al siguiente elemento del arreglo. Hacer otra verificacion if donde en caso de que no exista dicha posicion, se mande automaticamente al archivo 0
    4) Dentro del if mandar a llamar a una funcion que verifique, mediante un switch, el valor del elemento que se esta analizando para ser enviado a uno de los archivos, tras primero  haber convertido ese arreglo a un String 
    5) Leer archivos en orden e ir colocando los elementos de cada archivo en el archivo original. 
    6) Volver a hacer todo, recursivo...
    */
    String nombre;
    int tipoOrdenamiento;
    String[] numeros;
    double[] numerosDouble;
    String[] numeros0;
    String[] numeros1;
    String[] numeros2;
    String[] numeros3;
    String[] numeros4;
    String[] numeros5;
    String[] numeros6;
    String[] numeros7;
    String[] numeros8;
    String[] numeros9;
    ArrayList<Integer> prueba = new ArrayList<>();
    
    
    Distribucion(String nombre,int tipoOrdenamiento){
        this.nombre = nombre;
        this.tipoOrdenamiento = tipoOrdenamiento;
        try{
            FileReader archivo = new FileReader(nombre);
            BufferedReader barchivo = new BufferedReader(archivo);
            while(true){
                String valor = barchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble[i] = Double.parseDouble(numeros[i]);
                }
            }
        }catch(IOException e){
            System.out.println("ERROR EN ARCHIVO");
        }
    }
    
    void radixSort(){
        int valor;
        try{
            
           
            
            FileReader lf2 = new FileReader("d2");
            FileReader lf3 = new FileReader("d3");
            FileReader lf4 = new FileReader("d4");
            FileReader lf5 = new FileReader("d5");
            FileReader lf6 = new FileReader("d6");
            FileReader lf7 = new FileReader("d7");
            FileReader lf8 = new FileReader("d8");
            FileReader lf9 = new FileReader("d9");
            FileReader lf0 = new FileReader("d0");
            
            BufferedReader blf1 = new BufferedReader(lf1);
            BufferedReader blf2 = new BufferedReader(lf2);
            BufferedReader blf3 = new BufferedReader(lf3);
            BufferedReader blf4 = new BufferedReader(lf4);
            BufferedReader blf5 = new BufferedReader(lf5);
            BufferedReader blf6 = new BufferedReader(lf6);
            BufferedReader blf7 = new BufferedReader(lf7);
            BufferedReader blf8 = new BufferedReader(lf8);
            BufferedReader bf9 = new  BufferedReader(lf9);
            BufferedReader blf0 = new BufferedReader(lf0);
            
            
            /*
            for(int n=10;n>-1;n--){
                
                for(int i=0; i<numeros.length; i++){
                    
                    valor = Integer.parseInt(String.valueOf(numeros[i].charAt(n)));
                    
                    switch(valor){
                        case 0:
                            f0.write(numeros0[i]);
                            f0.write(",");
                            break;
                        case 1:
                            f1.write(numeros1[i]);
                            f1.write(",");
                            break;
                        case 2:
                            f2.write(numeros2[i]);
                            f2.write(",");
                            break;
                        case 3:
                            f3.write(numeros3[i]);
                            f3.write(",");
                            break;
                        case 4:
                            f4.write(numeros4[i]);
                            f4.write(",");
                            break;
                        case 5:
                            f5.write(numeros5[i]);
                            f5.write(",");
                            break;
                        case 6:
                            f6.write(numeros6[i]);
                            f6.write(",");
                            break;
                        case 7:
                            f7.write(numeros7[i]);
                            f7.write(",");
                            break;
                        case 8:
                            f8.write(numeros8[i]);
                            f8.write(",");
                            break;
                        case 9:
                            f9.write(numeros9[i]);
                            f9.write(",");
                            break;     
                    }
                }
                
                int pos = 0;
                for(int j=0; j<10;j++){
                    switch(j){
                        case 0:
                            while(true){
                                String desarchivar = blf0.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros0 = desarchivar.split(",");    
                            }
                            break;
                        
                        case 1:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros1 = desarchivar.split(",");    
                            }
                            break;
                        
                        case 2:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros2 = desarchivar.split(",");    
                            }
                            break;
                         
                        case 3:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros3 = desarchivar.split(",");    
                            }
                            break;
                        
                        case 4:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros4 = desarchivar.split(",");    
                            }
                            break;
                        
                        case 5:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros5 = desarchivar.split(",");    
                            }
                            break;
                        
                        case 6:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros6 = desarchivar.split(",");    
                            }
                            break;
                        
                        case 7:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros7 = desarchivar.split(",");    
                            }
                            break;
                            
                        case 8:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros8 = desarchivar.split(",");    
                            }
                            break;
                            
                        case 9:
                            while(true){
                                String desarchivar = blf1.readLine();
                                if(desarchivar == null)
                                    break;
                                numeros9 = desarchivar.split(",");    
                            }
                            break;   
                    }
                }
            
                
                
                FileWriter f = new FileWriter(nombre,false);
            }*/
          for(int i=0; i<numerosDouble.length; i++){
              double numero = numerosDouble[i];
              int digitosAntes = String.valueOf(numero).split("\\.")[0].length();
              int digitosDespues = String.valueOf(numero).split("\\.")[1].length();
              
              for(int j=digitosDespues-1;j>-1;j++){
                  
              }
              
              
              
          }  
        }catch(IOException e){
            System.out.println("ERROR DE ARCHIVO");
        }
    }
        
}
