package ordenamientoexterno;

import java.util.*;
import java.io.*;

/**
 *
 * @author AndresBasile
 */
public class MezclaEquilibrada {
    /* 
    1) Leer todo el archivo y guardar sus elementos en un arreglo, tomando en consideracion las comas.
    2) Crear dos nuevos Archivo.
    3) Primer ciclo for recorrer arreglo de numeros original, verificar tamano del arreglo.
    4) Dentro del ciclo for, ciclo while donde verifique que arr[j+1] sea mayor que arr[j], anadiendo los numeros al archivo 1, cuando no se cumple sale y avisa la posicion j+1. Anadir marcador de que acabo bloque.
    5) Otro ciclo while donde verifique que arr[j+1] sea mayor que arr[j], empezando en j+1 anadiendo los numeros al archivo 2, cuando no se cumple sale y avisa la posicion j+1, para la siguiente iteracion del ciclo for del archivo 1. Anadir marcador de que acabo bloque.
    6) Leer de ambos archivos hasta los marcadores y guardar cada bloque en un arreglo para archivo 1 y archivo 2, realizar merge de ambos bloques y almacenarlo en el archivo original, donde se debio borrar todo previamente.
    7) Avanzar al siguiente bloque de los dos archivos
    8) Funcion recursiva de mezcla equilibrada para ordenar, verificando que el arreglo del archivo original este ordenado. Sobre el archivo original no se marcadores.
    */
    
    String nombre;
    int tipoOrdenamiento;
    String numeros[];
    String bloque1Original[];
    String bloque1[];
    String bloque2[];
    String bloque1OriginalAux[];
    String bloque1Aux[];
    String bloque2Aux[];
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    ArrayList<String> bloqueArchivo1String = new ArrayList<>();
    ArrayList<String> bloqueArchivo2String = new ArrayList<>();
    static String nomAux1 = "AuxiliarMezclaEquilibrada1.txt";
    static String nomAux2 = "AuxiliarMezclaEquilibrada2.txt";
    
    MezclaEquilibrada(String archivo, int tipoOrdenamiento){
        this.nombre = archivo;
        this.tipoOrdenamiento = tipoOrdenamiento;  
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }      
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    
    void bloques(){
        int m;
        try{
            FileWriter archivoOriginal = new FileWriter(nombre,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1;
                        
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }

            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");//SOBREESCRIBIR EL ARCHIVO ORIGINAL PARA GUARDAR MERGE DE BLOQUES
            archivoOriginal.close();
            
            
        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    } 
    
    
    void mergearRecursivo(){
        try{
        FileReader laux1 = new FileReader(nomAux1);
        FileReader laux2 = new FileReader(nomAux2);
        BufferedReader blaux1 = new BufferedReader(laux1);
        BufferedReader blaux2 = new BufferedReader(laux2);
        boolean verificaDiagonal=false;
            
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque1 = numero.split("/");
                for(int i = 0;i<bloque1.length;i++){
                    if(bloque1[i]!=null){
                        bloque1Aux = bloque1[i].split(",");
                        for(int j=0; j<bloque1Aux.length;j++){
                            bloqueArchivo1String.add((bloque1Aux[j]));
                        }
                        bloqueArchivo1String.add("/");
                    }
                }  
                System.out.println("Bloque1");
                for(String d : bloqueArchivo1String){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux1.close();
            
            while(true){
                String numero = blaux2.readLine();
                if(numero == null)
                    break;
                bloque2 = numero.split("/");
                for(int i = 0;i<bloque2.length;i++){
                    if(bloque2[i]!=null){
                        bloque2Aux = bloque2[i].split(",");
                        for(int j=0; j<bloque2Aux.length;j++){
                            bloqueArchivo2String.add((bloque2Aux[j]));
                        }
                        bloqueArchivo2String.add("/");
                    }
                }  
                System.out.println("Bloque2");
                for(String d : bloqueArchivo2String){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux2.close();
            
            FileWriter archivoOriginal = new FileWriter(nombre,true);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))<Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal.write(",");
                        }
                    }
                    else{
                        archivoOriginal.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal.write(",");
                        }
                    }               
                } //bien
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo1String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal.write(",");
                    }   
                }
            }
            archivoOriginal.close();

        }catch(IOException e){
            System.out.println("error");
            e.printStackTrace();
        }
            //Verificar que no haya barras en el archivo original, si no hay, salir y ya está ordenado
            //*********************************************//
        /*try{
            FileReader archivoOriginal = new FileReader(nombre);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);
            FileWriter aux1 = new FileWriter(nomAux1,false);
            FileWriter aux2 = new FileWriter(nomAux2,false);
            
            while(true){
                
                //*******************
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
                //**********************
                
                
                System.out.println("BloqueOriginal");
                for(String d : bloqueArchivoOriginalString){
                    System.out.println(d);
                }
                System.out.println();
                
                while(!bloqueArchivoOriginalString.isEmpty()){
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        aux1.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux1.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux1.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        aux2.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux2.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux2.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
                
               
            }
               
            bArchivoOriginal.close();
            aux1.close();
            aux2.close();
        }catch(IOException e){
            System.out.println("ERROR¿?");
        } */
        
        
        
    }
    
}
