package ordenamientoexterno;

import java.util.*;
import java.io.*;

/**
 *
 * @author AndresBasile
 */
public class MezclaEquilibrada {

    String nombre;
    int tipoOrdenamiento;
    String numeros[];
    String bloque1Original[];
    String bloque1[];
    String bloque2[];
    String bloque1OriginalAux[];
    String bloque1Aux[];
    String bloque2Aux[];
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivoOriginalString = new ArrayList<>();
    ArrayList<Double> bloqueArchivoOriginalDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivo1String = new ArrayList<>();
    ArrayList<String> bloqueArchivo2String = new ArrayList<>();
    static String nomAux1 = "AuxiliarMezclaEquilibrada1.txt";
    static String nomAux2 = "AuxiliarMezclaEquilibrada2.txt";
    
    MezclaEquilibrada(String archivo, int tipoOrdenamiento){
        this.nombre = archivo;
        this.tipoOrdenamiento = tipoOrdenamiento;  
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }      
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    public void bloques(){
        try{
            FileWriter archivoOriginal = new FileWriter(nombre,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1;
                        
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }

            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    public void lecturaArchivoAuxiliar1(){
        try{
            FileReader laux1 = new FileReader(nomAux1); 
            BufferedReader blaux1 = new BufferedReader(laux1);
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                bloque1 = numero.split("/");
                for(int i = 0;i<bloque1.length;i++){
                    if(bloque1[i]!=null){
                        bloque1Aux = bloque1[i].split(",");
                        for(int j=0; j<bloque1Aux.length;j++){
                            bloqueArchivo1String.add((bloque1Aux[j]));
                        }
                        bloqueArchivo1String.add("/");
                    }
                }  
                System.out.println("Bloque1");
                for(String d : bloqueArchivo1String){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void lecturaArchivoAuxiliar2(){
        try{
            FileReader laux2 = new FileReader(nomAux2);
            BufferedReader blaux2 = new BufferedReader(laux2);
            while(true){
                String numero = blaux2.readLine();
                if(numero == null)
                    break;
                bloque2 = numero.split("/");
                for(int i = 0;i<bloque2.length;i++){
                    if(bloque2[i]!=null){
                        bloque2Aux = bloque2[i].split(",");
                        for(int j=0; j<bloque2Aux.length;j++){
                            bloqueArchivo2String.add((bloque2Aux[j]));
                        }
                        bloqueArchivo2String.add("/");
                    }
                }  
                System.out.println("Bloque2");
                for(String d : bloqueArchivo2String){
                    System.out.println(d);
                }
                System.out.println();
            }
            laux2.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void escrituraBloquesArchivoOriginal(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombre,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))<Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                } //bien
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo2String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public boolean verificaOrdenamiento(){
        boolean verificaOrdenamiento = true;
        int contadLasLineas = 0;
        for(int m=0; m<bloqueArchivoOriginalString.size(); m++){
            if(bloqueArchivoOriginalString.get(m)=="/"){  
                contadLasLineas++;
            }
        } 
        if(contadLasLineas==1||contadLasLineas==0){
            verificaOrdenamiento = true;
        }
        else{
            verificaOrdenamiento=false;
        }
        bloqueArchivoOriginalString.clear();
        return verificaOrdenamiento;
    }
    
    public void borrarTodo(){
        bloqueArchivoOriginalString.clear();
        bloqueArchivoOriginalDouble.clear();
        bloqueArchivo1String.clear();
        bloqueArchivo2String.clear();
        numeros = null;
        bloque1Original = null;
        bloque1 = null;
        bloque2 = null;
        bloque1OriginalAux= null;
        bloque1Aux = null;
        bloque2Aux = null;
        bloque1Aux = null;
    }
    
    public void lecturaArchivoOriginal(){
        try{
            FileReader archivoOriginal = new FileReader(nombre);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);

            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
            }
            bArchivoOriginal.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void leerArchivoOriginalPasarAAuxiliares(){

        try{
            FileReader archivoOriginal = new FileReader(nombre);
            BufferedReader bArchivoOriginal = new BufferedReader(archivoOriginal);
            FileWriter aux1 = new FileWriter(nomAux1,false);
            FileWriter aux2 = new FileWriter(nomAux2,false);
            
            while(true){
                String numero = bArchivoOriginal.readLine();
                if(numero == null)
                    break;
                bloque1Original = numero.split("/");
                for(int i = 0;i<bloque1Original.length;i++){
                    if(bloque1Original[i]!=null){
                        bloque1OriginalAux = bloque1Original[i].split(",");
                        for(int j=0; j<bloque1OriginalAux.length;j++){
                            bloqueArchivoOriginalString.add((bloque1OriginalAux[j]));
                        }
                        bloqueArchivoOriginalString.add("/");
                    }
                }  
                
                System.out.println("BloqueOriginal");
                for(String d : bloqueArchivoOriginalString){
                    System.out.println(d);
                }
                System.out.println();
                
                while(!bloqueArchivoOriginalString.isEmpty()){
                    while(bloqueArchivoOriginalString.get(0)!="/"){
                        aux1.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux1.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux1.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)!="/"){
                        aux2.write(bloqueArchivoOriginalString.remove(0));
                        if(bloqueArchivoOriginalString.get(0)!="/"){
                            aux2.write(",");
                        }   
                    }
                    if(!bloqueArchivoOriginalString.isEmpty()){
                        aux2.write("/");
                    }
                    while(!bloqueArchivoOriginalString.isEmpty()&&bloqueArchivoOriginalString.get(0)=="/"){
                        bloqueArchivoOriginalString.remove(0);
                    }
                }
            }
            bArchivoOriginal.close();
            aux1.close();
            aux2.close();
        }catch(IOException e){
            System.out.println("ERROR¿?");
        } 
        
        
        
    }
    
    public void bloquesDescendente(){
        try{
            FileWriter archivoOriginal = new FileWriter(nombre,false);
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            
            int contador = 0;
            int termina = 1;
            while(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)<numerosDouble.get(contador)&&numerosDouble.get(contador+1)!=null){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                        termina=1;
                        
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                    termina=2;
                if(1<numerosDouble.size()){
                    while(numerosDouble.size()>1&&numerosDouble.get(contador+1)<numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                        termina=2;
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                    termina=1;
                }
            }
            if(!numerosDouble.isEmpty()){
                if(termina == 1){
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/");                    
                }
                if(termina == 2){
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");                    
                }

            }
            aux1.close();
            aux2.close();
            archivoOriginal.write("");
            archivoOriginal.close();

        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    public void escrituraBloquesArchivoOriginalDescendente(){
        boolean verificaDiagonal = false;
        try{
            FileWriter archivoOriginal1 = new FileWriter(nombre,false);
            while(!bloqueArchivo1String.isEmpty()&&!bloqueArchivo2String.isEmpty()){
                verificaDiagonal=false;
                while(bloqueArchivo1String.get(0)!="/"&&bloqueArchivo2String.get(0)!="/"){
                    if(Double.parseDouble(bloqueArchivo1String.get(0))>Double.parseDouble(bloqueArchivo2String.get(0))){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }
                    else{
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }               
                } //bien
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    while(bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo2String.remove(0));
                        if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    while(bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(bloqueArchivo1String.remove(0));
                        if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                            archivoOriginal1.write(",");
                        }
                    }    
                }
                if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)=="/"){
                    bloqueArchivo1String.remove(0);
                    archivoOriginal1.write("/");
                    verificaDiagonal=true;
                }
                if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)=="/"){
                    bloqueArchivo2String.remove(0);
                    if(verificaDiagonal=false){
                        archivoOriginal1.write("/");
                    }
                }
            }
            while(!bloqueArchivo1String.isEmpty()||!bloqueArchivo1String.isEmpty()){
                if(!bloqueArchivo1String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo1String.remove(0));
                    if(!bloqueArchivo1String.isEmpty()&&bloqueArchivo1String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
                 if(!bloqueArchivo2String.isEmpty()){
                    archivoOriginal1.write(bloqueArchivo2String.remove(0));
                    if(!bloqueArchivo2String.isEmpty()&&bloqueArchivo2String.get(0)!="/"){
                        archivoOriginal1.write(",");
                    }   
                }
            }
            archivoOriginal1.close();
        }
        catch(IOException e){
            System.out.println("Error");
            e.printStackTrace();
        }
    }
    
    public void ordenamiento(){
        if(tipoOrdenamiento==1){
            bloques();
            do{
                lecturaArchivoAuxiliar1();
                lecturaArchivoAuxiliar2();
                escrituraBloquesArchivoOriginal();
                leerArchivoOriginalPasarAAuxiliares();
                lecturaArchivoOriginal();
            }while(verificaOrdenamiento()==false);            
        }
        
        if(tipoOrdenamiento == 2){
           bloquesDescendente();
            do{
                lecturaArchivoAuxiliar1();
                lecturaArchivoAuxiliar2();
                escrituraBloquesArchivoOriginalDescendente();
                leerArchivoOriginalPasarAAuxiliares();
                lecturaArchivoOriginal();
            }while(verificaOrdenamiento()==false); 
        }
    }
    
}
