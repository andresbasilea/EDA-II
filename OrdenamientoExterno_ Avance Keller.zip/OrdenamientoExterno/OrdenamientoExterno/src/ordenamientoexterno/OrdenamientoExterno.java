/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamientoexterno;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 *
 * @author AndresBasile
 */
public class OrdenamientoExterno {
    static Scanner sc = new Scanner(System.in);
    
    public static void main(String[] args){
        System.out.println("\nORDENAMIENTO EXTERNO\n\nBienvenido al programa de ordenamiento externo de archivos\n***\nCreadores:\n\tBasile Álvarez Andrés José\n\tKeller Ascencio Rodolfo Andrés\n\tMartínez Jiménez María Fernanda\n***\n");
        int opc = 1;
        while(opc>0 && opc<4){
            System.out.println("\n\n¿Qué método de ordenamiento desea utilizar?\n1)Método por polifase \n2)Método por mezcla equilibrada \n3)Método por distribución (radix)\n4)Salir\nIngrese: ");
            opc = sc.nextInt();
            switch(opc){
                case 1:
                    sc.nextLine();
                    System.out.println("Debe ingresar el nombre del archivo a ordenar ***EL NOMBRE DEBE INCLUIR LA EXTENSIÓN DEL ARCHIVO (.txt)***\nIngrese: ");
                    String nombreArchivo = sc.nextLine();
                    System.out.println("Ingrese el tipo de ordenamiento deseado: \n1)Ascendente\n2)Descendente\nIngrese: ");
                    int tipo = sc.nextInt();
                    Polifase polifase = new Polifase(nombreArchivo,tipo);
                    polifase.ordenar();
                    
                    break;
                case 2:
                    sc.nextLine();
                    System.out.println("Debe ingresar el nombre del archivo a ordenar ***EL NOMBRE DEBE INCLUIR LA EXTENSIÓN DEL ARCHIVO (.txt)***\nIngrese: ");
                    nombreArchivo = sc.nextLine();
                    System.out.println("Ingrese el tipo de ordenamiento deseado: \n1)Ascendente\n2)Descendente\nIngrese: ");
                    tipo = sc.nextInt();
                    break;
                case 3:
                    sc.nextLine();
                    System.out.println("Debe ingresar el nombre del archivo a ordenar ***EL NOMBRE DEBE INCLUIR LA EXTENSIÓN DEL ARCHIVO (.txt)***\nIngrese: ");
                    nombreArchivo = sc.nextLine();
                    System.out.println("Ingrese el tipo de ordenamiento deseado: \n1)Ascendente\n2)Descendente\nIngrese: ");
                    tipo = sc.nextInt();
                    Distribucion distribucion = new Distribucion(nombreArchivo,tipo);
                    distribucion.MetodoDistribucion();
                    break;
                default:
                    break;      
            }
            
            
            
        }
    }
    
}
