/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamientoexterno;

/**
 *
 * @author AndresBasile
 */
public class Quicksort {
    int partitionAscendente(double arr[], int low, int high){
        double pivot = arr[high];
        int j,i = (low -1);
        for(j=low;j<high; j++){
            if(arr[j]<= pivot){
                i++;
                double temp = arr[i];
    	        arr[i] = arr[j];
    	        arr[j] = temp;
            }
        }
    	
        double temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;
        return i+1;
    }

    void sortAscendente(double arr[], int low, int high){
        if(low<high){
            int pi = partitionAscendente(arr, low, high);
            sortAscendente(arr,low,pi-1);
            sortAscendente(arr,pi+1,high);
        }
    }
    
   /* void sortDescendente(double arr[], int low, int high){
        if(low<high){
            int pi = partitionAscendente(arr, low, high);
            sortAscendente(arr,low,pi-1);
            sortAscendente(arr,pi+1,high);
        }
    }
    
    int partitionDescendente(double arr[],int low, int high){
        double pivot = arr[high];
        int j,i = (low -1);
        for(j=low;j<high; j++){
            if(arr[j]>= pivot){
                i++;
                double temp = arr[i];
    	        arr[i] = arr[j];
    	        arr[j] = temp;
            }
        }
    	
        double temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;
        return i+1;
    }*/
}
