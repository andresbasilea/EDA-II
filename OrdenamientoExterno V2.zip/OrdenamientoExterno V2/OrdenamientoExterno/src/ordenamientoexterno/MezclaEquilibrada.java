package ordenamientoexterno;

import java.util.*;
import java.io.*;

/**
 *
 * @author AndresBasile
 */
public class MezclaEquilibrada {
    /* 
    1) Leer todo el archivo y guardar sus elementos en un arreglo, tomando en consideracion las comas.
    2) Crear dos nuevos Archivo.
    3) Primer ciclo for recorrer arreglo de numeros original, verificar tamano del arreglo.
    4) Dentro del ciclo for, ciclo while donde verifique que arr[j+1] sea mayor que arr[j], anadiendo los numeros al archivo 1, cuando no se cumple sale y avisa la posicion j+1. Anadir marcador de que acabo bloque.
    5) Otro ciclo while donde verifique que arr[j+1] sea mayor que arr[j], empezando en j+1 anadiendo los numeros al archivo 2, cuando no se cumple sale y avisa la posicion j+1, para la siguiente iteracion del ciclo for del archivo 1. Anadir marcador de que acabo bloque.
    6) Leer de ambos archivos hasta los marcadores y guardar cada bloque en un arreglo para archivo 1 y archivo 2, realizar merge de ambos bloques y almacenarlo en el archivo original, donde se debio borrar todo previamente.
    7) Avanzar al siguiente bloque de los dos archivos
    8) Funcion recursiva de mezcla equilibrada para ordenar, verificando que el arreglo del archivo original este ordenado. Sobre el archivo original no se marcadores.
    */
    
    String nombre;
    int tipoOrdenamiento;
    String numeros[];  
    ArrayList<Double> numerosDouble = new ArrayList<>();
    ArrayList<String> bloqueArchivo1 = new ArrayList<>();
    ArrayList<String> bloqueArchivo2 = new ArrayList<>();
    ArrayList<Double> bloqueArchivo1Double = new ArrayList<>();
    ArrayList<Double> bloqueArchivo2Double = new ArrayList<>();
    
    MezclaEquilibrada(String archivo, int tipoOrdenamiento){
        this.nombre = archivo;
        this.tipoOrdenamiento = tipoOrdenamiento;  
        try{
            FileReader lArchivo = new FileReader(nombre);
            BufferedReader lbArchivo = new BufferedReader(lArchivo);
            while(true){
                String valor = lbArchivo.readLine();
                if(valor == null)
                    break;
                numeros = valor.split(",");
                for(int i = 0;i<numeros.length;i++){
                    if(numeros[i]!=null)
                        numerosDouble.add(Double.parseDouble(numeros[i]));
                }      
            }
            lArchivo.close();
        }catch(IOException e){
            System.out.println("ERROR EN EL NOMBRE DEL ARCHIVO");
        }
    }
    
    
    void ordenar(){
        int m;
        try{
            FileWriter archivoOriginal = new FileWriter(nombre,false);
            String nomAux1 = "AuxiliarMezclaEquilibrada1.txt";
            String nomAux2 = "AuxiliarMezclaEquilibrada2.txt";
            FileWriter aux1 = new FileWriter(nomAux1);
            FileWriter aux2 = new FileWriter(nomAux2);
            int contador = 0;
            while(contador+1<numerosDouble.size()&&!numerosDouble.isEmpty()){
                if(contador+1<numerosDouble.size()&&!numerosDouble.isEmpty()){
                    while(numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux1.write(numerosDouble.remove(contador).toString());
                        aux1.write(",");
                    }
                    aux1.write(numerosDouble.remove(contador).toString());
                    aux1.write("/"); 
                }
                if(contador+1<numerosDouble.size()&&!numerosDouble.isEmpty()){
                    while(numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux2.write(numerosDouble.remove(contador).toString());
                        aux2.write(",");
                    }
                    aux2.write(numerosDouble.remove(contador).toString());
                    aux2.write("/");
                }
            }
            if(!numerosDouble.isEmpty()){
                aux1.write(numerosDouble.remove(contador).toString());
                aux1.write("/"); 
            }
           // }
            /*while(!numerosDouble.isEmpty()){
                for(int i=0;i<numerosDouble.size();i++){
                    for(int j=0; j<numerosDouble.size()-i-1;j++){
                        if(numerosDouble.get(i)>numerosDouble.get(j)){
                            aux1.write(numerosDouble.get(i));
                        }
                    }
                }
            }*/
            FileReader laux1 = new FileReader(nomAux1);
            FileReader laux2 = new FileReader(nomAux2);
            BufferedReader blaux1 = new BufferedReader(laux1);
            BufferedReader blaux2 = new BufferedReader(laux2);
            
            while(true){
                String numero = blaux1.readLine();
                if(numero == null)
                    break;
                if(numero != "/"){
                    bloqueArchivo1.add(numero.split(",").toString());
                    for(int i = 0;i<bloqueArchivo1.size();i++){
                        if(bloqueArchivo1.get(i)!=null)
                            bloqueArchivo1Double.add(Double.parseDouble(bloqueArchivo1.get(i)));
                    }
                }
            }
            laux1.close();
            
            while(true){
                String numero = blaux2.readLine();
                if(numero == null)
                    break;
                if(numero != "/"){
                   bloqueArchivo2.add(numero.split(",").toString());
                    for(int i = 0;i<bloqueArchivo2.size();i++){
                        if(bloqueArchivo2.get(i)!=null)
                            bloqueArchivo2Double.add(Double.parseDouble(bloqueArchivo2.get(i)));
                    }
                }
            }
            laux2.close();
            archivoOriginal.write("");//SOBREESCRIBIR EL ARCHIVO ORIGINAL PARA GUARDAR MERGE DE BLOQUES
            archivoOriginal.close();
            aux1.close();
            aux2.close();
            
        }catch(IOException e){
            System.out.println("ERROR EN EL ARCHIVO");
            e.printStackTrace();
        }            
    }
    
    /*
    while(contador+1<numerosDouble.size()){
                System.out.println(m);
                if(contador+1<numerosDouble.size()){
                    while(numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux1.write(numerosDouble.get(contador).toString());
                        aux1.write(",");
                        contador++;
                    }
                    aux1.write(numerosDouble.get(contador).toString());
                    aux1.write("/");
                    contador++;  
                }
                else{
                    aux1.write(numerosDouble.get(contador).toString());
                    aux1.write("/");
                }
                if(contador+1<numerosDouble.size()){
                    while(numerosDouble.get(contador+1)>numerosDouble.get(contador)){
                        aux2.write(numerosDouble.get(contador).toString());
                        aux2.write(",");
                        contador++;
                    }
                    aux2.write(numerosDouble.get(contador).toString());
                    aux2.write("/");
                    contador++;
                }
                else{
                    aux2.write(numerosDouble.get(contador).toString());
                    aux2.write("/");
                }     
            }
    */
    
    
    
    
    
    
    
    
    
    
}
